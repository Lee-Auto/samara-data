# Samara Data — Instrucciones de instalación

## Paso 1: Crear subdominio en Hostinger

1. Entra a hPanel (panel.hostinger.com)
2. Ve a **Hosting → Administrar → Subdominios**
3. Crea el subdominio: `samara.tudominio.com`
4. Apunta la carpeta raíz a: `public_html/samara`

## Paso 2: Crear base de datos MySQL

1. En hPanel ve a **Bases de datos MySQL**
2. Crea una nueva base de datos (anota el nombre)
3. Crea un usuario y asígnalo a esa base de datos con todos los permisos
4. Anota: nombre_bd, usuario, contraseña

## Paso 3: Importar el schema de base de datos

1. En hPanel ve a **phpMyAdmin**
2. Selecciona tu base de datos recién creada
3. Ve a la pestaña **Importar**
4. Sube el archivo `database/schema.sql`
5. Haz clic en **Continuar**

## Paso 4: Configurar el archivo de conexión

1. Abre el archivo `config/config.php`
2. Edita estas 4 líneas con tus datos:
   ```php
   define('DB_NAME', 'tu_base_de_datos');   // el nombre de tu BD
   define('DB_USER', 'tu_usuario_mysql');   // el usuario creado
   define('DB_PASS', 'tu_password_mysql');  // la contraseña
   define('APP_URL', 'https://samara.tudominio.com'); // tu subdominio real
   ```

## Paso 5: Subir los archivos

1. En hPanel ve a **Administrador de archivos**
2. Navega a `public_html/samara/` (créala si no existe)
3. Sube **todos los archivos de este ZIP** dentro de esa carpeta
   - La estructura debe quedar: `public_html/samara/index.php`, `public_html/samara/config/`, etc.

## Paso 6: Primer acceso

Abre tu navegador y entra a: `https://samara.tudominio.com`

Credenciales iniciales:
- **Email:** admin@samara.com
- **Contraseña:** Admin1234

**¡IMPORTANTE!** Cambia la contraseña inmediatamente después de entrar.
Ve a la esquina superior derecha → tu nombre → Cambiar contraseña.

---

## Flujo de trabajo recomendado

1. **Primero:** Dar de alta los ítems base (materiales individuales con su zona Z1-Z6)
2. **Segundo:** Crear artículos (agrupaciones de ítems, ej: "Ventana tipo 1")
3. **Tercero:** Crear objetos y asignarles artículos (ej: Objeto "A" = Pared sin apertura)
4. **Cuarto:** Ir a "Nuevo BOM", ingresar el código (ej: AABC) y generar

---

## Solución de problemas comunes

**"Error de conexión a base de datos"**
→ Verifica que los datos en `config/config.php` sean exactamente los del hPanel

**Página en blanco**
→ Activa el log de errores en hPanel → PHP → Logs

**El archivo .htaccess no funciona**
→ Verifica que mod_rewrite esté activado en tu plan Hostinger Business (viene activado por defecto)
