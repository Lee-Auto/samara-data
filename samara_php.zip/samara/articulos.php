<?php
// public/articulos.php
require_once __DIR__ . '/../src/bootstrap.php';
auth_check();
$model = new Articulo();
$item_model = new Item();
$accion = $_GET['accion'] ?? 'listar';
$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_articulo'])) {
    csrf_verify();
    if (!is_editor()) { flash_set('error','Sin permisos.'); redirect('/articulos.php'); }
    $data = ['codigo'=>trim($_POST['codigo']??''),'nombre'=>trim($_POST['nombre']??''),'descripcion'=>trim($_POST['descripcion']??'')];
    if (empty($data['codigo'])||empty($data['nombre'])) { flash_set('error','Código y nombre requeridos.'); redirect('/articulos.php'); }
    if ($id) { $model->actualizar($id,$data); flash_set('success','Artículo actualizado.'); }
    else { $id = $model->crear($data,auth_user()['id']); flash_set('success','Artículo creado.'); }

    // Guardar componentes
    $comps = [];
    $tipos  = $_POST['comp_tipo'] ?? [];
    $refs   = $_POST['comp_ref'] ?? [];
    $fmls   = $_POST['comp_formula'] ?? [];
    $notas  = $_POST['comp_notas'] ?? [];
    foreach ($tipos as $i => $tipo) {
        if (empty($refs[$i])) continue;
        $comps[] = [
            'item_id'        => $tipo==='item' ? (int)$refs[$i] : null,
            'sub_articulo_id'=> $tipo==='articulo' ? (int)$refs[$i] : null,
            'formula_cantidad'=> $fmls[$i] ?? '1',
            'notas'          => $notas[$i] ?? '',
        ];
    }
    $model->guardar_componentes($id, $comps);
    redirect('/articulos.php');
}

if ($accion==='eliminar'&&$id&&is_editor()) { $model->eliminar($id); flash_set('success','Artículo eliminado.'); redirect('/articulos.php'); }

$busqueda = trim($_GET['q']??'');
$articulos = $model->listar($busqueda);
$todos_items = $item_model->listar();
$todos_articulos = $model->listar();
$art_edit = $id&&in_array($accion,['editar']) ? $model->buscar_por_id($id) : null;
$comps_edit = $art_edit ? $model->obtener_componentes($id) : [];

ob_start(); ?>
<div class="row g-4">
  <div class="col-md-<?= $art_edit?'7':'12' ?>">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <form class="d-flex gap-2" method="GET"><input type="text" name="q" value="<?= e($busqueda) ?>" class="form-control form-control-sm" placeholder="Buscar…" style="width:200px"><button class="btn btn-sm btn-outline-secondary">Filtrar</button></form>
      <?php if(is_editor()):?><a href="/articulos.php?accion=editar" class="btn btn-sm btn-primary"><i class="bi bi-plus me-1"></i>Nuevo artículo</a><?php endif;?>
    </div>
    <div class="card">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead><tr><th>Código</th><th>Nombre</th><th>Componentes</th><?php if(is_editor()):?><th></th><?php endif;?></tr></thead>
          <tbody>
          <?php if(empty($articulos)):?><tr><td colspan="4" class="text-center text-muted py-4">Sin artículos.</td></tr>
          <?php else: foreach($articulos as $a):
            $n=$a['id']?Database::get()->prepare('SELECT COUNT(*) FROM articulo_componentes WHERE articulo_id=?'):null;
            if($n){$n->execute([$a['id']]);$cnt=$n->fetchColumn();}else{$cnt=0;}
          ?>
          <tr>
            <td><code><?= e($a['codigo']) ?></code></td>
            <td class="fw-medium"><?= e($a['nombre']) ?></td>
            <td><span class="badge bg-light text-dark"><?= $cnt ?> comp.</span></td>
            <?php if(is_editor()):?>
            <td class="text-end">
              <a href="/articulos.php?accion=editar&id=<?= $a['id'] ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-pencil"></i></a>
              <a href="/articulos.php?accion=eliminar&id=<?= $a['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('¿Eliminar?')"><i class="bi bi-trash"></i></a>
            </td>
            <?php endif;?>
          </tr>
          <?php endforeach; endif;?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <?php if(is_editor()&&in_array($accion,['editar'])):?>
  <div class="col-md-5">
    <div class="card">
      <div class="card-header"><?= $art_edit?'Editar artículo':'Nuevo artículo' ?></div>
      <div class="card-body">
        <form method="POST">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <input type="hidden" name="guardar_articulo" value="1">
          <div class="mb-2"><label class="form-label fw-medium small">Código *</label>
            <input type="text" name="codigo" class="form-control form-control-sm" value="<?= e($art_edit['codigo']??'') ?>" required></div>
          <div class="mb-2"><label class="form-label fw-medium small">Nombre *</label>
            <input type="text" name="nombre" class="form-control form-control-sm" value="<?= e($art_edit['nombre']??'') ?>" required></div>
          <div class="mb-3"><label class="form-label fw-medium small">Descripción</label>
            <textarea name="descripcion" class="form-control form-control-sm" rows="2"><?= e($art_edit['descripcion']??'') ?></textarea></div>

          <div class="fw-medium small mb-2">Componentes</div>
          <div id="comps_lista">
          <?php foreach($comps_edit as $c): ?>
            <div class="comp-row border rounded p-2 mb-2 small">
              <div class="row g-1">
                <div class="col-4">
                  <select name="comp_tipo[]" class="form-select form-select-sm" onchange="cambiarTipo(this)">
                    <option value="item" <?= $c['item_id']?'selected':'' ?>>Ítem base</option>
                    <option value="articulo" <?= $c['sub_articulo_id']?'selected':'' ?>>Sub-artículo</option>
                  </select>
                </div>
                <div class="col-4">
                  <select name="comp_ref[]" class="form-select form-select-sm ref-select">
                    <?php if($c['item_id']): foreach($todos_items as $it): ?>
                      <option value="<?= $it['id'] ?>" <?= $it['id']==$c['item_id']?'selected':'' ?>><?= e($it['nombre']) ?></option>
                    <?php endforeach; elseif($c['sub_articulo_id']): foreach($todos_articulos as $ta): ?>
                      <option value="<?= $ta['id'] ?>" <?= $ta['id']==$c['sub_articulo_id']?'selected':'' ?>><?= e($ta['nombre']) ?></option>
                    <?php endforeach; endif;?>
                  </select>
                </div>
                <div class="col-2"><input type="text" name="comp_formula[]" class="form-control form-control-sm" value="<?= e($c['formula_cantidad']) ?>" placeholder="fórmula"></div>
                <div class="col-2 d-flex gap-1">
                  <input type="text" name="comp_notas[]" class="form-control form-control-sm" value="<?= e($c['notas']??'') ?>" placeholder="nota">
                  <button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('.comp-row').remove()"><i class="bi bi-x"></i></button>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
          </div>

          <button type="button" class="btn btn-sm btn-outline-secondary mb-3" onclick="agregarComp()">
            <i class="bi bi-plus me-1"></i>Agregar componente
          </button>

          <div class="d-flex gap-2">
            <button type="submit" class="btn btn-sm btn-primary">Guardar</button>
            <a href="/articulos.php" class="btn btn-sm btn-outline-secondary">Cancelar</a>
          </div>
        </form>
      </div>
    </div>
  </div>
  <?php endif; ?>
</div>

<script>
const todosItems = <?= json_encode(array_map(fn($i)=>['id'=>$i['id'],'nombre'=>$i['nombre']], $todos_items)) ?>;
const todosArticulos = <?= json_encode(array_map(fn($a)=>['id'=>$a['id'],'nombre'=>$a['nombre']], $todos_articulos)) ?>;

function agregarComp() {
    const lista = document.getElementById('comps_lista');
    const tpl = document.createElement('div');
    tpl.className = 'comp-row border rounded p-2 mb-2 small';
    tpl.innerHTML = `<div class="row g-1">
      <div class="col-4"><select name="comp_tipo[]" class="form-select form-select-sm" onchange="cambiarTipo(this)">
        <option value="item">Ítem base</option><option value="articulo">Sub-artículo</option></select></div>
      <div class="col-4"><select name="comp_ref[]" class="form-select form-select-sm ref-select">
        ${todosItems.map(i=>`<option value="${i.id}">${i.nombre}</option>`).join('')}</select></div>
      <div class="col-2"><input type="text" name="comp_formula[]" class="form-control form-control-sm" value="1" placeholder="fórmula"></div>
      <div class="col-2 d-flex gap-1"><input type="text" name="comp_notas[]" class="form-control form-control-sm" placeholder="nota">
        <button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('.comp-row').remove()"><i class="bi bi-x"></i></button>
      </div></div>`;
    lista.appendChild(tpl);
}

function cambiarTipo(sel) {
    const lista = sel.value === 'item' ? todosItems : todosArticulos;
    const ref = sel.closest('.comp-row').querySelector('.ref-select');
    ref.innerHTML = lista.map(i=>`<option value="${i.id}">${i.nombre}</option>`).join('');
}
</script>
<?php
$contenido = ob_get_clean();
$titulo = 'Artículos';
require_once __DIR__ . '/../views/layout.php';
