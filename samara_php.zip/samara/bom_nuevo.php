<?php
require_once __DIR__ . '/../src/bootstrap.php';
auth_check();
if (!is_editor()) { flash_set('error', 'Sin permisos.'); redirect('/boms.php'); }

$objeto_model = new Objeto();
$objetos = $objeto_model->listar();

// Procesar generación de BOM
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $nombre      = trim($_POST['nombre'] ?? '');
    $codigo      = strtoupper(trim($_POST['codigo_config'] ?? ''));
    $notas       = trim($_POST['notas'] ?? '');
    $params_raw  = trim($_POST['parametros'] ?? '');

    // Parsear parámetros clave=valor, uno por línea
    $parametros = [];
    foreach (explode("\n", $params_raw) as $linea) {
        $linea = trim($linea);
        if (strpos($linea, '=') !== false) {
            [$k, $v] = array_map('trim', explode('=', $linea, 2));
            if ($k !== '' && is_numeric($v)) $parametros[$k] = (float)$v;
        }
    }

    if (empty($nombre) || empty($codigo)) {
        flash_set('error', 'Nombre y código de configuración son requeridos.');
        redirect('/bom_nuevo.php');
    }

    // Explotar BOM
    $engine  = new BomEngine(Database::get(), $parametros);
    $resultado = $engine->explotar($codigo);

    if (empty($resultado['agrupado'])) {
        flash_set('warning', 'No se encontraron ítems para ese código. Verifica que los objetos estén bien configurados.');
        redirect('/bom_nuevo.php');
    }

    // Guardar
    $bom_model = new Bom();
    $bom_id = $bom_model->crear([
        'nombre'          => $nombre,
        'codigo_config'   => $codigo,
        'parametros_json' => !empty($parametros) ? json_encode($parametros) : null,
        'notas'           => $notas,
        'estado'          => 'borrador',
        'version'         => 1,
    ], auth_user()['id']);

    $bom_model->guardar_lineas($bom_id, $resultado['agrupado']);
    flash_set('success', 'BOM generado con ' . count($resultado['agrupado']) . ' ítems.');
    redirect('/bom_ver.php?id=' . $bom_id);
}

ob_start(); ?>
<div class="row g-4">
  <div class="col-md-7">
    <div class="card">
      <div class="card-header">Generar nuevo BOM</div>
      <div class="card-body">
        <form method="POST">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

          <div class="mb-3">
            <label class="form-label fw-medium">Nombre del BOM <span class="text-danger">*</span></label>
            <input type="text" name="nombre" class="form-control" placeholder="Ej: Casa Modelo A - Cliente López" required>
          </div>

          <div class="mb-3">
            <label class="form-label fw-medium">Código de configuración <span class="text-danger">*</span></label>
            <input type="text" name="codigo_config" id="codigo_input" class="form-control font-monospace text-uppercase"
                   placeholder="Ej: AABC" oninput="previsualizar(this.value)" autocomplete="off">
            <div class="form-text">Cada letra corresponde a un objeto. También puedes usar formato extendido: <code>PARED1:A,BAÑO:B</code></div>
            <div id="preview_config" class="mt-2"></div>
          </div>

          <div class="mb-3">
            <label class="form-label fw-medium">Parámetros de dimensión</label>
            <textarea name="parametros" class="form-control font-monospace" rows="4"
                      placeholder="largo=6.5&#10;ancho=4.2&#10;alto=2.7"></textarea>
            <div class="form-text">Un parámetro por línea en formato <code>nombre=valor</code>. Se usan en las fórmulas de cantidad de los artículos.</div>
          </div>

          <div class="mb-3">
            <label class="form-label fw-medium">Notas</label>
            <textarea name="notas" class="form-control" rows="2"></textarea>
          </div>

          <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary"><i class="bi bi-lightning me-1"></i>Generar BOM</button>
            <a href="/boms.php" class="btn btn-outline-secondary">Cancelar</a>
          </div>
        </form>
      </div>
    </div>
  </div>

  <div class="col-md-5">
    <div class="card">
      <div class="card-header">Objetos disponibles</div>
      <div class="table-responsive">
        <table class="table table-sm mb-0">
          <thead><tr><th>Letra</th><th>Nombre</th><th>Tipo</th></tr></thead>
          <tbody>
          <?php if (empty($objetos)): ?>
            <tr><td colspan="3" class="text-center text-muted py-3">
              No hay objetos aún. <a href="/objetos.php">Crear primero</a>
            </td></tr>
          <?php else: ?>
            <?php foreach ($objetos as $obj): ?>
            <tr>
              <td><kbd><?= e($obj['letra_config']) ?></kbd></td>
              <td><?= e($obj['nombre']) ?></td>
              <td><span class="text-muted small"><?= e($obj['tipo']) ?></span></td>
            </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<script>
const objetos = <?= json_encode(array_column($objetos, 'nombre', 'letra_config')) ?>;
function previsualizar(codigo) {
    const div = document.getElementById('preview_config');
    if (!codigo) { div.innerHTML = ''; return; }
    codigo = codigo.toUpperCase();
    let html = '<div class="d-flex flex-wrap gap-2 mt-2">';
    if (codigo.includes(':')) {
        codigo.split(',').forEach(par => {
            const [pos, letra] = par.split(':').map(s=>s.trim());
            if (!pos || !letra) return;
            const nombre = objetos[letra] || '<span class="text-danger">No encontrado</span>';
            html += `<div class="border rounded px-2 py-1 small"><span class="fw-bold">${pos}</span>: <kbd>${letra}</kbd> ${nombre}</div>`;
        });
    } else {
        [...codigo].forEach((letra, i) => {
            const nombre = objetos[letra] || '<span class="text-danger">?</span>';
            html += `<div class="border rounded px-2 py-1 small"><span class="text-muted">pos ${i+1}</span>: <kbd>${letra}</kbd> ${nombre}</div>`;
        });
    }
    html += '</div>';
    div.innerHTML = html;
}
</script>
<?php
$contenido = ob_get_clean();
$titulo = 'Nuevo BOM';
require_once __DIR__ . '/../views/layout.php';
