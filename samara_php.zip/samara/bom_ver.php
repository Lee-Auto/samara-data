<?php
require_once __DIR__ . '/../src/bootstrap.php';
auth_check();

$bom_model = new Bom();
$id = (int)($_GET['id'] ?? 0);
$bom = $bom_model->buscar_por_id($id);
if (!$bom) { flash_set('error', 'BOM no encontrado.'); redirect('/boms.php'); }

// Exportar CSV
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $lineas = $bom_model->obtener_lineas($id);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="BOM_' . $id . '_v' . $bom['version'] . '.csv"');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM UTF-8 para Excel
    fputcsv($out, ['Zona','Número parte','Nombre','Cantidad','Unidad','Origen objeto','Origen artículo']);
    foreach ($lineas as $l) {
        fputcsv($out, [$l['zona'],$l['numero_parte'],$l['nombre'],formato_cantidad((float)$l['cantidad_calculada']),$l['unidad_medida'],$l['origen_objeto'],$l['origen_articulo']]);
    }
    fclose($out);
    exit;
}

// Crear nueva versión
if (isset($_GET['nueva_version']) && is_editor()) {
    $nuevo_id = $bom_model->crear_version($id, auth_user()['id']);
    flash_set('success', 'Nueva versión creada.');
    redirect('/bom_ver.php?id=' . $nuevo_id);
}

// Cambiar estado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cambiar_estado'])) {
    csrf_verify();
    $bom_model->actualizar_estado($id, $_POST['estado']);
    flash_set('success', 'Estado actualizado.');
    redirect('/bom_ver.php?id=' . $id);
}

$lineas = $bom_model->obtener_lineas($id);
$parametros = json_decode_safe($bom['parametros_json'] ?? '{}', []);

// Agrupar por zona
$por_zona = [];
foreach ($lineas as $l) {
    $por_zona[$l['zona']][] = $l;
}

ob_start(); ?>
<div class="d-flex justify-content-between align-items-start mb-3">
  <div>
    <div class="d-flex align-items-center gap-2 mb-1">
      <span class="badge bg-<?= $bom['estado'] === 'finalizado' ? 'success' : 'secondary' ?>"><?= $bom['estado'] ?></span>
      <span class="badge bg-primary">v<?= $bom['version'] ?></span>
      <?php if ($bom['bom_padre_id']): ?>
      <a href="/bom_ver.php?id=<?= $bom['bom_padre_id'] ?>" class="badge bg-light text-dark text-decoration-none">
        <i class="bi bi-arrow-up"></i> Ver v<?= $bom['version'] - 1 ?>
      </a>
      <?php endif; ?>
    </div>
    <p class="text-muted mb-0 small">
      Código: <code><?= e($bom['codigo_config']) ?></code> &nbsp;·&nbsp;
      Creado por <?= e($bom['creado_por'] ?? '?') ?> el <?= date('d/m/Y H:i', strtotime($bom['created_at'])) ?>
    </p>
    <?php if (!empty($parametros)): ?>
    <p class="text-muted mb-0 small mt-1">
      Parámetros: <?= implode(', ', array_map(fn($k,$v) => "$k=$v", array_keys($parametros), $parametros)) ?>
    </p>
    <?php endif; ?>
  </div>
  <div class="d-flex gap-2 flex-wrap justify-content-end">
    <?php if (is_editor()): ?>
      <a href="/bom_ver.php?id=<?= $id ?>&nueva_version=1" class="btn btn-sm btn-outline-primary"
         onclick="return confirm('¿Crear nueva versión de este BOM?')">
        <i class="bi bi-copy me-1"></i>Nueva versión
      </a>
    <?php endif; ?>
    <a href="/bom_ver.php?id=<?= $id ?>&export=csv" class="btn btn-sm btn-outline-success">
      <i class="bi bi-download me-1"></i>Exportar CSV
    </a>
    <?php if (is_editor() && $bom['estado'] === 'borrador'): ?>
    <form method="POST" class="d-inline">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
      <input type="hidden" name="cambiar_estado" value="1">
      <input type="hidden" name="estado" value="finalizado">
      <button type="submit" class="btn btn-sm btn-success"
              onclick="return confirm('¿Finalizar este BOM?')">
        <i class="bi bi-check-circle me-1"></i>Finalizar
      </button>
    </form>
    <?php endif; ?>
  </div>
</div>

<!-- Resumen por zonas -->
<div class="row g-2 mb-4">
  <?php foreach (ZONAS as $zona => $label): ?>
    <?php $n = count($por_zona[$zona] ?? []); if(!$n) continue; ?>
    <div class="col-auto">
      <a href="#zona-<?= $zona ?>" class="badge-zona badge-<?= $zona ?> text-decoration-none" style="font-size:12px;padding:5px 12px">
        <?= $zona ?>: <?= $n ?> ítems
      </a>
    </div>
  <?php endforeach; ?>
  <div class="col-auto ms-auto">
    <span class="text-muted small"><?= count($lineas) ?> ítems totales</span>
  </div>
</div>

<?php if (empty($lineas)): ?>
  <div class="card"><div class="card-body text-center text-muted py-5">Este BOM no tiene líneas. Intenta regenerarlo.</div></div>
<?php else: ?>
  <?php foreach (ZONAS as $zona => $label): ?>
    <?php if (empty($por_zona[$zona])) continue; ?>
    <div class="card mb-3" id="zona-<?= $zona ?>">
      <div class="card-header d-flex align-items-center gap-2">
        <span class="badge-zona badge-<?= $zona ?>"><?= $zona ?></span>
        <span class="fw-medium"><?= e($label) ?></span>
        <span class="text-muted small ms-auto"><?= count($por_zona[$zona]) ?> ítems</span>
      </div>
      <div class="table-responsive">
        <table class="table table-sm table-hover mb-0">
          <thead><tr><th>Núm. parte</th><th>Nombre</th><th class="text-end">Cantidad</th><th>Unidad</th><th>Origen</th></tr></thead>
          <tbody>
          <?php foreach ($por_zona[$zona] as $l): ?>
          <tr>
            <td><code class="small"><?= e($l['numero_parte']) ?></code></td>
            <td><?= e($l['nombre']) ?></td>
            <td class="text-end fw-medium"><?= formato_cantidad((float)$l['cantidad_calculada']) ?></td>
            <td class="text-muted"><?= e($l['unidad_medida']) ?></td>
            <td class="text-muted small"><?= e($l['origen_objeto'] ?? '') ?></td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  <?php endforeach; ?>
<?php endif; ?>

<?php if ($bom['notas']): ?>
<div class="card mt-3">
  <div class="card-header">Notas</div>
  <div class="card-body text-muted small"><?= nl2br(e($bom['notas'])) ?></div>
</div>
<?php endif; ?>

<?php
$contenido = ob_get_clean();
$titulo = e($bom['nombre']);
require_once __DIR__ . '/../views/layout.php';
