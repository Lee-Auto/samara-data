<?php
require_once __DIR__ . '/../src/bootstrap.php';
auth_check();
$bom_model = new Bom();
$busqueda = trim($_GET['q'] ?? '');
$boms = $bom_model->listar(0, $busqueda);
ob_start(); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <form class="d-flex gap-2" method="GET">
    <input type="text" name="q" value="<?= e($busqueda) ?>" class="form-control form-control-sm" placeholder="Buscar BOM…" style="width:240px">
    <button class="btn btn-sm btn-outline-secondary">Buscar</button>
  </form>
  <?php if (is_editor()): ?>
  <a href="/bom_nuevo.php" class="btn btn-sm btn-primary"><i class="bi bi-plus me-1"></i>Nuevo BOM</a>
  <?php endif; ?>
</div>
<div class="card">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead><tr><th>Nombre</th><th>Código</th><th>Ver.</th><th>Estado</th><th>Ítems</th><th>Creado por</th><th>Fecha</th><th></th></tr></thead>
      <tbody>
      <?php if (empty($boms)): ?>
        <tr><td colspan="8" class="text-center text-muted py-4">No hay BOMs. <a href="/bom_nuevo.php">Crear el primero</a></td></tr>
      <?php else: ?>
        <?php
        $db = Database::get();
        foreach ($boms as $b):
            $n_items = $db->prepare('SELECT COUNT(*) FROM bom_lineas WHERE bom_id=?');
            $n_items->execute([$b['id']]);
            $cnt = $n_items->fetchColumn();
        ?>
        <tr>
          <td class="fw-medium"><?= e($b['nombre']) ?></td>
          <td><code><?= e($b['codigo_config']) ?></code></td>
          <td>v<?= $b['version'] ?></td>
          <td><span class="badge bg-<?= $b['estado']==='finalizado'?'success':'secondary' ?>"><?= $b['estado'] ?></span></td>
          <td><?= $cnt ?></td>
          <td><?= e($b['creado_por'] ?? '—') ?></td>
          <td class="text-muted small"><?= date('d/m/Y', strtotime($b['created_at'])) ?></td>
          <td><a href="/bom_ver.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-outline-secondary">Ver</a></td>
        </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
$contenido = ob_get_clean();
$titulo = 'BOMs guardados';
require_once __DIR__ . '/../views/layout.php';
