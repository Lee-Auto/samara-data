<?php
// ============================================================
// config/config.php — Configuración central
// EDITAR estos valores antes de subir a Hostinger
// ============================================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'tu_base_de_datos');   // <-- cambiar
define('DB_USER', 'tu_usuario_mysql');   // <-- cambiar
define('DB_PASS', 'tu_password_mysql');  // <-- cambiar
define('DB_CHARSET', 'utf8mb4');

define('APP_NAME', 'Samara Data');
define('APP_URL', 'https://samara.tudominio.com'); // <-- cambiar
define('APP_VERSION', '1.0.0');

// Sesión
define('SESSION_NAME', 'samara_session');
define('SESSION_LIFETIME', 3600 * 8); // 8 horas

// Zonas disponibles
define('ZONAS', [
    'Z1' => 'Acero estructural',
    'Z2' => 'Tubería / plomería / eléctrico',
    'Z3' => 'Interiores',
    'Z4' => 'Exteriores',
    'Z5' => 'Acabados',
    'Z6' => 'Varios',
]);

// Unidades de medida comunes
define('UNIDADES', [
    'pza', 'mt', 'ml', 'kg', 'lt', 'm2', 'm3', 'rollo', 'caja', 'juego', 'tramo'
]);

// Roles
define('ROL_ADMIN',  'admin');
define('ROL_EDITOR', 'editor');
define('ROL_VISOR',  'visor');

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
