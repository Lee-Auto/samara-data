-- ============================================================
-- SAMARA DATA — Schema de base de datos
-- Ejecutar este archivo en phpMyAdmin una sola vez
-- ============================================================

SET NAMES utf8mb4;
SET foreign_key_checks = 0;

-- ------------------------------------------------------------
-- Usuarios y autenticación
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    rol ENUM('admin','editor','visor') NOT NULL DEFAULT 'editor',
    activo TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Usuario admin inicial (password: Admin1234)
INSERT INTO usuarios (nombre, email, password_hash, rol) VALUES
('Administrador', 'admin@samara.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- ------------------------------------------------------------
-- Catálogo: Ítems base
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero_parte VARCHAR(100) NOT NULL UNIQUE,
    nombre VARCHAR(200) NOT NULL,
    descripcion TEXT,
    unidad_medida VARCHAR(50) NOT NULL DEFAULT 'pza',
    zona VARCHAR(10) NOT NULL DEFAULT 'Z1',
    activo TINYINT(1) NOT NULL DEFAULT 1,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Catálogo: Artículos (sub-ensambles, pueden anidarse)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS articulos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(100) NOT NULL UNIQUE,
    nombre VARCHAR(200) NOT NULL,
    descripcion TEXT,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Componentes de un artículo: puede ser ítem base O sub-artículo
CREATE TABLE IF NOT EXISTS articulo_componentes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    articulo_id INT NOT NULL,
    item_id INT NULL,
    sub_articulo_id INT NULL,
    formula_cantidad VARCHAR(255) NOT NULL DEFAULT '1',
    notas VARCHAR(255),
    orden INT NOT NULL DEFAULT 0,
    FOREIGN KEY (articulo_id) REFERENCES articulos(id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE,
    FOREIGN KEY (sub_articulo_id) REFERENCES articulos(id) ON DELETE CASCADE,
    -- Solo uno de los dos puede estar lleno
    CONSTRAINT chk_componente CHECK (
        (item_id IS NOT NULL AND sub_articulo_id IS NULL) OR
        (item_id IS NULL AND sub_articulo_id IS NOT NULL)
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Catálogo: Objetos completos (pared A, baño, sala…)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS objetos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    letra_config VARCHAR(20) NOT NULL UNIQUE,
    nombre VARCHAR(200) NOT NULL,
    descripcion TEXT,
    tipo VARCHAR(100) DEFAULT 'pared',
    activo TINYINT(1) NOT NULL DEFAULT 1,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Artículos que componen un objeto
CREATE TABLE IF NOT EXISTS objeto_articulos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    objeto_id INT NOT NULL,
    articulo_id INT NOT NULL,
    formula_cantidad VARCHAR(255) NOT NULL DEFAULT '1',
    notas VARCHAR(255),
    orden INT NOT NULL DEFAULT 0,
    FOREIGN KEY (objeto_id) REFERENCES objetos(id) ON DELETE CASCADE,
    FOREIGN KEY (articulo_id) REFERENCES articulos(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- BOMs generados
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS boms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(200) NOT NULL,
    codigo_config VARCHAR(500) NOT NULL,
    parametros_json TEXT,
    notas TEXT,
    estado ENUM('borrador','finalizado') NOT NULL DEFAULT 'borrador',
    version INT NOT NULL DEFAULT 1,
    bom_padre_id INT NULL,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (bom_padre_id) REFERENCES boms(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Líneas del BOM (resultado de la explosión)
CREATE TABLE IF NOT EXISTS bom_lineas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bom_id INT NOT NULL,
    item_id INT NOT NULL,
    cantidad_calculada DECIMAL(12,4) NOT NULL,
    zona VARCHAR(10) NOT NULL,
    origen_objeto VARCHAR(100),
    origen_articulo VARCHAR(200),
    FOREIGN KEY (bom_id) REFERENCES boms(id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET foreign_key_checks = 1;
