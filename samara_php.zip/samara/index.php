<?php
require_once __DIR__ . '/../src/bootstrap.php';
auth_check();
$db = Database::get();
$total_items    = $db->query('SELECT COUNT(*) FROM items WHERE activo=1')->fetchColumn();
$total_articulos= $db->query('SELECT COUNT(*) FROM articulos WHERE activo=1')->fetchColumn();
$total_objetos  = $db->query('SELECT COUNT(*) FROM objetos WHERE activo=1')->fetchColumn();
$total_boms     = $db->query('SELECT COUNT(*) FROM boms')->fetchColumn();
$boms_recientes = $db->query('SELECT b.*, u.nombre as creado_por FROM boms b LEFT JOIN usuarios u ON u.id=b.created_by ORDER BY b.created_at DESC LIMIT 5')->fetchAll();

ob_start(); ?>
<div class="row g-3 mb-4">
  <?php foreach ([
    ['Ítems base','bi-box',$total_items,'primary','/items.php'],
    ['Artículos','bi-boxes',$total_articulos,'success','/articulos.php'],
    ['Objetos','bi-building',$total_objetos,'warning','/objetos.php'],
    ['BOMs generados','bi-table',$total_boms,'danger','/boms.php'],
  ] as [$label,$icon,$val,$color,$url]): ?>
  <div class="col-6 col-md-3">
    <a href="<?= $url ?>" class="text-decoration-none">
      <div class="card h-100">
        <div class="card-body d-flex align-items-center gap-3">
          <div class="rounded-3 p-2 bg-<?= $color ?> bg-opacity-10 text-<?= $color ?>">
            <i class="bi <?= $icon ?> fs-4"></i>
          </div>
          <div>
            <div class="fw-bold fs-4"><?= $val ?></div>
            <div class="text-muted small"><?= $label ?></div>
          </div>
        </div>
      </div>
    </a>
  </div>
  <?php endforeach; ?>
</div>

<div class="card">
  <div class="card-header d-flex align-items-center justify-content-between">
    <span>BOMs recientes</span>
    <a href="/bom_nuevo.php" class="btn btn-sm btn-primary"><i class="bi bi-plus me-1"></i>Nuevo BOM</a>
  </div>
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead><tr><th>Nombre</th><th>Código</th><th>Versión</th><th>Estado</th><th>Creado por</th><th>Fecha</th><th></th></tr></thead>
      <tbody>
      <?php if (empty($boms_recientes)): ?>
        <tr><td colspan="7" class="text-center text-muted py-4">No hay BOMs aún. <a href="/bom_nuevo.php">Crear el primero</a></td></tr>
      <?php else: ?>
        <?php foreach ($boms_recientes as $b): ?>
        <tr>
          <td class="fw-medium"><?= e($b['nombre']) ?></td>
          <td><code><?= e($b['codigo_config']) ?></code></td>
          <td>v<?= $b['version'] ?></td>
          <td>
            <span class="badge bg-<?= $b['estado'] === 'finalizado' ? 'success' : 'secondary' ?>">
              <?= $b['estado'] ?>
            </span>
          </td>
          <td><?= e($b['creado_por'] ?? '—') ?></td>
          <td class="text-muted small"><?= date('d/m/Y H:i', strtotime($b['created_at'])) ?></td>
          <td><a href="/bom_ver.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-outline-secondary">Ver</a></td>
        </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
$contenido = ob_get_clean();
$titulo = 'Dashboard';
require_once __DIR__ . '/../views/layout.php';
