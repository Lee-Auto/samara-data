<?php
require_once __DIR__ . '/../src/bootstrap.php';
auth_check();

$item_model = new Item();
$accion = $_GET['accion'] ?? 'listar';
$id = (int)($_GET['id'] ?? 0);

// Procesar POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (!is_editor()) { flash_set('error', 'Sin permisos.'); redirect('/items.php'); }
    $data = [
        'numero_parte'  => trim($_POST['numero_parte'] ?? ''),
        'nombre'        => trim($_POST['nombre'] ?? ''),
        'descripcion'   => trim($_POST['descripcion'] ?? ''),
        'unidad_medida' => trim($_POST['unidad_medida'] ?? 'pza'),
        'zona'          => trim($_POST['zona'] ?? 'Z1'),
    ];
    if (empty($data['numero_parte']) || empty($data['nombre'])) {
        flash_set('error', 'Número de parte y nombre son requeridos.');
    } elseif ($id) {
        $item_model->actualizar($id, $data);
        flash_set('success', 'Ítem actualizado correctamente.');
    } else {
        $item_model->crear($data, auth_user()['id']);
        flash_set('success', 'Ítem creado correctamente.');
    }
    redirect('/items.php');
}

if ($accion === 'eliminar' && $id && is_editor()) {
    $item_model->eliminar($id);
    flash_set('success', 'Ítem eliminado.');
    redirect('/items.php');
}

$busqueda = trim($_GET['q'] ?? '');
$zona_filtro = $_GET['zona'] ?? '';
$items = $item_model->listar($busqueda, $zona_filtro);
$item_edit = $id ? $item_model->buscar_por_id($id) : null;

ob_start(); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <div class="d-flex gap-2">
    <form class="d-flex gap-2" method="GET">
      <input type="text" name="q" value="<?= e($busqueda) ?>" class="form-control form-control-sm" placeholder="Buscar…" style="width:200px">
      <select name="zona" class="form-select form-select-sm" style="width:140px">
        <option value="">Todas las zonas</option>
        <?php foreach (ZONAS as $k => $v): ?>
        <option value="<?= $k ?>" <?= $zona_filtro === $k ? 'selected' : '' ?>><?= $k ?> — <?= $v ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn btn-sm btn-outline-secondary">Filtrar</button>
    </form>
  </div>
  <?php if (is_editor()): ?>
  <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#modalItem">
    <i class="bi bi-plus me-1"></i>Nuevo ítem
  </button>
  <?php endif; ?>
</div>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead>
        <tr><th>Núm. parte</th><th>Nombre</th><th>Unidad</th><th>Zona</th><th>Descripción</th><?php if(is_editor()):?><th></th><?php endif;?></tr>
      </thead>
      <tbody>
      <?php if (empty($items)): ?>
        <tr><td colspan="6" class="text-center text-muted py-4">Sin ítems. <?php if(is_editor()):?><a href="#" data-bs-toggle="modal" data-bs-target="#modalItem">Agregar primero</a><?php endif;?></td></tr>
      <?php else: ?>
        <?php foreach ($items as $it): ?>
        <tr>
          <td><code><?= e($it['numero_parte']) ?></code></td>
          <td class="fw-medium"><?= e($it['nombre']) ?></td>
          <td><?= e($it['unidad_medida']) ?></td>
          <td><span class="badge-zona badge-<?= e($it['zona']) ?>"><?= e($it['zona']) ?></span></td>
          <td class="text-muted small"><?= e(mb_strimwidth($it['descripcion'] ?? '', 0, 60, '…')) ?></td>
          <?php if (is_editor()): ?>
          <td class="text-end">
            <a href="/items.php?accion=editar&id=<?= $it['id'] ?>" class="btn btn-xs btn-outline-secondary btn-sm"
               data-edit='<?= json_encode($it) ?>' onclick="abrirEditar(this);return false;">
              <i class="bi bi-pencil"></i>
            </a>
            <a href="/items.php?accion=eliminar&id=<?= $it['id'] ?>" class="btn btn-xs btn-outline-danger btn-sm"
               onclick="return confirm('¿Eliminar este ítem?')">
              <i class="bi bi-trash"></i>
            </a>
          </td>
          <?php endif; ?>
        </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal crear/editar -->
<div class="modal fade" id="modalItem" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
        <input type="hidden" name="id" id="edit_id" value="">
        <div class="modal-header">
          <h5 class="modal-title" id="modalItemTitulo">Nuevo ítem</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label fw-medium">Número de parte <span class="text-danger">*</span></label>
            <input type="text" name="numero_parte" id="edit_np" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label fw-medium">Nombre <span class="text-danger">*</span></label>
            <input type="text" name="nombre" id="edit_nombre" class="form-control" required>
          </div>
          <div class="row g-2 mb-3">
            <div class="col">
              <label class="form-label fw-medium">Unidad de medida</label>
              <select name="unidad_medida" id="edit_um" class="form-select">
                <?php foreach (UNIDADES as $u): ?><option value="<?= $u ?>"><?= $u ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="col">
              <label class="form-label fw-medium">Zona</label>
              <select name="zona" id="edit_zona" class="form-select">
                <?php foreach (ZONAS as $k => $v): ?><option value="<?= $k ?>"><?= $k ?> — <?= $v ?></option><?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label fw-medium">Descripción</label>
            <textarea name="descripcion" id="edit_desc" class="form-control" rows="2"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-primary">Guardar</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function abrirEditar(btn) {
    const d = JSON.parse(btn.dataset.edit);
    document.getElementById('modalItemTitulo').textContent = 'Editar ítem';
    document.getElementById('edit_id').value = d.id;
    document.getElementById('edit_np').value = d.numero_parte;
    document.getElementById('edit_nombre').value = d.nombre;
    document.getElementById('edit_um').value = d.unidad_medida;
    document.getElementById('edit_zona').value = d.zona;
    document.getElementById('edit_desc').value = d.descripcion || '';
    new bootstrap.Modal(document.getElementById('modalItem')).show();
}
document.getElementById('modalItem').addEventListener('hidden.bs.modal', () => {
    document.getElementById('edit_id').value = '';
    document.getElementById('modalItemTitulo').textContent = 'Nuevo ítem';
    document.querySelector('#modalItem form').reset();
});
</script>
<?php
$contenido = ob_get_clean();
$titulo = 'Ítems base';
require_once __DIR__ . '/../views/layout.php';
