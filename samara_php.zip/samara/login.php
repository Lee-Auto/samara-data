<?php
// public/login.php
require_once __DIR__ . '/../src/bootstrap.php';

if (!empty($_SESSION['user_id'])) redirect('/index.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $usuario  = new Usuario();
    $user     = $usuario->buscar_por_email($email);
    if ($user && $usuario->verificar_password($password, $user['password_hash'])) {
        auth_login($user);
        redirect('/index.php');
    }
    $error = 'Correo o contraseña incorrectos.';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Iniciar sesión — <?= APP_NAME ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<style>
body { background: #1a1a2e; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
.login-card { background: #fff; border-radius: 16px; padding: 40px; width: 100%; max-width: 400px; }
.login-logo { font-size: 28px; font-weight: 700; color: #1a1a2e; margin-bottom: 4px; }
.login-sub { color: #6b7280; font-size: 14px; margin-bottom: 28px; }
</style>
</head>
<body>
<div class="login-card shadow-lg">
  <div class="login-logo"><i class="bi bi-layers-half me-2"></i><?= APP_NAME ?></div>
  <div class="login-sub">Sistema de gestión de BOM</div>
  <?php if ($error): ?>
  <div class="alert alert-danger py-2"><?= e($error) ?></div>
  <?php endif; ?>
  <form method="POST">
    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
    <div class="mb-3">
      <label class="form-label fw-medium">Correo electrónico</label>
      <input type="email" name="email" class="form-control" required autofocus>
    </div>
    <div class="mb-4">
      <label class="form-label fw-medium">Contraseña</label>
      <input type="password" name="password" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary w-100 py-2">Entrar</button>
  </form>
</div>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</body>
</html>
