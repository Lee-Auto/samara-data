<?php
// public/logout.php
require_once __DIR__ . '/../src/bootstrap.php';
auth_logout();
