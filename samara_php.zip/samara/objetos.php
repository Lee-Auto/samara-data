<?php
// public/objetos.php
require_once __DIR__ . '/../src/bootstrap.php';
auth_check();
$model = new Objeto();
$art_model = new Articulo();
$accion = $_GET['accion'] ?? 'listar';
$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_objeto'])) {
    csrf_verify();
    if (!is_editor()) { flash_set('error','Sin permisos.'); redirect('/objetos.php'); }
    $data = [
        'letra_config' => strtoupper(trim($_POST['letra_config']??'')),
        'nombre'       => trim($_POST['nombre']??''),
        'descripcion'  => trim($_POST['descripcion']??''),
        'tipo'         => trim($_POST['tipo']??'pared'),
    ];
    if (empty($data['letra_config'])||empty($data['nombre'])) { flash_set('error','Letra y nombre requeridos.'); redirect('/objetos.php?accion=editar'.($id?"&id=$id":'')); }
    if ($id) { $model->actualizar($id,$data); flash_set('success','Objeto actualizado.'); }
    else { $id = $model->crear($data,auth_user()['id']); flash_set('success','Objeto creado.'); }

    $arts = [];
    $art_ids  = $_POST['art_id'] ?? [];
    $formulas = $_POST['art_formula'] ?? [];
    $notas    = $_POST['art_notas'] ?? [];
    foreach ($art_ids as $i => $aid) {
        if (!$aid) continue;
        $arts[] = ['articulo_id'=>(int)$aid,'formula_cantidad'=>$formulas[$i]??'1','notas'=>$notas[$i]??''];
    }
    $model->guardar_articulos($id, $arts);
    redirect('/objetos.php');
}

if ($accion==='eliminar'&&$id&&is_editor()) { $model->eliminar($id); flash_set('success','Objeto eliminado.'); redirect('/objetos.php'); }

$objetos = $model->listar();
$todos_articulos = $art_model->listar();
$obj_edit = ($id&&$accion==='editar') ? $model->buscar_por_id($id) : null;
$arts_edit = $obj_edit ? $model->obtener_articulos($id) : [];

ob_start(); ?>
<div class="row g-4">
  <div class="col-md-<?= $obj_edit?'7':'12' ?>">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h6 class="mb-0 text-muted">Objetos configurados</h6>
      <?php if(is_editor()):?><a href="/objetos.php?accion=editar" class="btn btn-sm btn-primary"><i class="bi bi-plus me-1"></i>Nuevo objeto</a><?php endif;?>
    </div>
    <div class="card">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead><tr><th>Letra</th><th>Nombre</th><th>Tipo</th><th>Artículos</th><?php if(is_editor()):?><th></th><?php endif;?></tr></thead>
          <tbody>
          <?php if(empty($objetos)):?><tr><td colspan="5" class="text-center text-muted py-4">Sin objetos aún.</td></tr>
          <?php else: foreach($objetos as $o):
            $n=Database::get()->prepare('SELECT COUNT(*) FROM objeto_articulos WHERE objeto_id=?');
            $n->execute([$o['id']]);$cnt=$n->fetchColumn();
          ?>
          <tr>
            <td><kbd class="fs-6"><?= e($o['letra_config']) ?></kbd></td>
            <td class="fw-medium"><?= e($o['nombre']) ?></td>
            <td class="text-muted small"><?= e($o['tipo']) ?></td>
            <td><span class="badge bg-light text-dark"><?= $cnt ?> artículos</span></td>
            <?php if(is_editor()):?>
            <td class="text-end">
              <a href="/objetos.php?accion=editar&id=<?= $o['id'] ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-pencil"></i></a>
              <a href="/objetos.php?accion=eliminar&id=<?= $o['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('¿Eliminar?')"><i class="bi bi-trash"></i></a>
            </td>
            <?php endif;?>
          </tr>
          <?php endforeach; endif;?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <?php if(is_editor()&&$accion==='editar'):?>
  <div class="col-md-5">
    <div class="card">
      <div class="card-header"><?= $obj_edit?'Editar objeto':'Nuevo objeto' ?></div>
      <div class="card-body">
        <form method="POST">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <input type="hidden" name="guardar_objeto" value="1">
          <div class="row g-2 mb-2">
            <div class="col-4">
              <label class="form-label fw-medium small">Letra *</label>
              <input type="text" name="letra_config" class="form-control form-control-sm text-uppercase" maxlength="20" value="<?= e($obj_edit['letra_config']??'') ?>" required placeholder="A">
            </div>
            <div class="col-8">
              <label class="form-label fw-medium small">Tipo</label>
              <input type="text" name="tipo" class="form-control form-control-sm" value="<?= e($obj_edit['tipo']??'pared') ?>" placeholder="pared, baño, techo…">
            </div>
          </div>
          <div class="mb-2"><label class="form-label fw-medium small">Nombre *</label>
            <input type="text" name="nombre" class="form-control form-control-sm" value="<?= e($obj_edit['nombre']??'') ?>" required></div>
          <div class="mb-3"><label class="form-label fw-medium small">Descripción</label>
            <textarea name="descripcion" class="form-control form-control-sm" rows="2"><?= e($obj_edit['descripcion']??'') ?></textarea></div>

          <div class="fw-medium small mb-2">Artículos que lo componen</div>
          <div id="arts_lista">
          <?php foreach($arts_edit as $a): ?>
            <div class="art-row border rounded p-2 mb-2 small">
              <div class="row g-1 align-items-center">
                <div class="col-6">
                  <select name="art_id[]" class="form-select form-select-sm">
                    <?php foreach($todos_articulos as $ta): ?>
                    <option value="<?= $ta['id'] ?>" <?= $ta['id']==$a['articulo_id']?'selected':'' ?>><?= e($ta['nombre']) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="col-3"><input type="text" name="art_formula[]" class="form-control form-control-sm" value="<?= e($a['formula_cantidad']) ?>" placeholder="cant."></div>
                <div class="col-2"><input type="text" name="art_notas[]" class="form-control form-control-sm" value="<?= e($a['notas']??'') ?>" placeholder="nota"></div>
                <div class="col-1"><button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('.art-row').remove()"><i class="bi bi-x"></i></button></div>
              </div>
            </div>
          <?php endforeach; ?>
          </div>
          <button type="button" class="btn btn-sm btn-outline-secondary mb-3" onclick="agregarArt()">
            <i class="bi bi-plus me-1"></i>Agregar artículo
          </button>
          <div class="d-flex gap-2">
            <button type="submit" class="btn btn-sm btn-primary">Guardar</button>
            <a href="/objetos.php" class="btn btn-sm btn-outline-secondary">Cancelar</a>
          </div>
        </form>
      </div>
    </div>
  </div>
  <?php endif; ?>
</div>
<script>
const artsDisponibles = <?= json_encode(array_map(fn($a)=>['id'=>$a['id'],'nombre'=>$a['nombre']],$todos_articulos)) ?>;
function agregarArt(){
    const lista=document.getElementById('arts_lista');
    const d=document.createElement('div');
    d.className='art-row border rounded p-2 mb-2 small';
    const opts=artsDisponibles.map(a=>`<option value="${a.id}">${a.nombre}</option>`).join('');
    d.innerHTML=`<div class="row g-1 align-items-center">
      <div class="col-6"><select name="art_id[]" class="form-select form-select-sm">${opts}</select></div>
      <div class="col-3"><input type="text" name="art_formula[]" class="form-control form-control-sm" value="1" placeholder="cant."></div>
      <div class="col-2"><input type="text" name="art_notas[]" class="form-control form-control-sm" placeholder="nota"></div>
      <div class="col-1"><button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('.art-row').remove()"><i class="bi bi-x"></i></button></div>
    </div>`;
    lista.appendChild(d);
}
</script>
<?php
$contenido = ob_get_clean();
$titulo = 'Objetos';
require_once __DIR__ . '/../views/layout.php';
