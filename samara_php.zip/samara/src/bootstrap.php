<?php
// src/bootstrap.php — Se incluye en cada página

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/flash.php';
require_once __DIR__ . '/helpers/utils.php';
require_once __DIR__ . '/models/Usuario.php';
require_once __DIR__ . '/models/Item.php';
require_once __DIR__ . '/models/Articulo.php';
require_once __DIR__ . '/models/Objeto.php';
require_once __DIR__ . '/models/Bom.php';
require_once __DIR__ . '/helpers/bom_engine.php';

session_name(SESSION_NAME);
session_set_cookie_params(['lifetime' => SESSION_LIFETIME, 'httponly' => true, 'samesite' => 'Lax']);
session_start();
