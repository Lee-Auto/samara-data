<?php
// src/helpers/auth.php

function auth_check(): void {
    if (empty($_SESSION['user_id'])) {
        header('Location: /login.php');
        exit;
    }
}

function auth_require_role(string ...$roles): void {
    auth_check();
    if (!in_array($_SESSION['user_rol'] ?? '', $roles, true)) {
        http_response_code(403);
        die('Acceso no autorizado.');
    }
}

function auth_login(array $user): void {
    session_regenerate_id(true);
    $_SESSION['user_id']     = $user['id'];
    $_SESSION['user_nombre'] = $user['nombre'];
    $_SESSION['user_email']  = $user['email'];
    $_SESSION['user_rol']    = $user['rol'];
}

function auth_logout(): void {
    $_SESSION = [];
    session_destroy();
    header('Location: /login.php');
    exit;
}

function auth_user(): array {
    return [
        'id'     => $_SESSION['user_id']     ?? null,
        'nombre' => $_SESSION['user_nombre'] ?? '',
        'email'  => $_SESSION['user_email']  ?? '',
        'rol'    => $_SESSION['user_rol']    ?? '',
    ];
}

function is_admin(): bool {
    return ($_SESSION['user_rol'] ?? '') === ROL_ADMIN;
}

function is_editor(): bool {
    return in_array($_SESSION['user_rol'] ?? '', [ROL_ADMIN, ROL_EDITOR], true);
}
