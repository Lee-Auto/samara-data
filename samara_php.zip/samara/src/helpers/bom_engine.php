<?php
// src/helpers/bom_engine.php
// Motor central: toma un código de configuración y genera las líneas del BOM

class BomEngine {

    private PDO $db;
    private array $parametros;
    private array $lineas = [];
    private array $visitados = []; // evita recursión infinita

    public function __construct(PDO $db, array $parametros = []) {
        $this->db = $db;
        $this->parametros = $parametros;
    }

    /**
     * Punto de entrada principal.
     * $codigo_config: string tipo "AABC" donde cada posición es la letra de un objeto
     * Retorna array de líneas agrupadas y aplanadas
     */
    public function explotar(string $codigo_config): array {
        $this->lineas = [];
        $this->visitados = [];

        // Parsear el código: cada carácter es la letra de un objeto
        // Soporte futuro: formato "PARED:A,BAÑO:B,TECHO:A" si se vuelve más flexible
        $posiciones = $this->parsear_codigo($codigo_config);

        foreach ($posiciones as $posicion => $letra) {
            $objeto = $this->buscar_objeto($letra);
            if (!$objeto) continue;

            $this->explotar_objeto($objeto, $posicion);
        }

        return $this->agrupar_lineas();
    }

    /**
     * Parsea el código de configuración.
     * Soporta dos formatos:
     *   - Simple: "AABC"  → [0=>'A', 1=>'A', 2=>'B', 3=>'C']
     *   - Extendido: "PARED1:A,BAÑO:B" → ['PARED1'=>'A', 'BAÑO'=>'B']
     */
    private function parsear_codigo(string $codigo): array {
        $codigo = strtoupper(trim($codigo));

        if (strpos($codigo, ':') !== false) {
            // Formato extendido
            $resultado = [];
            foreach (explode(',', $codigo) as $par) {
                [$pos, $letra] = array_map('trim', explode(':', $par, 2));
                $resultado[$pos] = $letra;
            }
            return $resultado;
        }

        // Formato simple: cada carácter es una posición
        return str_split($codigo);
    }

    private function buscar_objeto(string $letra): ?array {
        $stmt = $this->db->prepare(
            'SELECT * FROM objetos WHERE letra_config = ? AND activo = 1 LIMIT 1'
        );
        $stmt->execute([$letra]);
        return $stmt->fetch() ?: null;
    }

    private function explotar_objeto(array $objeto, mixed $posicion): void {
        $stmt = $this->db->prepare(
            'SELECT oa.*, a.codigo, a.nombre as articulo_nombre
             FROM objeto_articulos oa
             JOIN articulos a ON a.id = oa.articulo_id
             WHERE oa.objeto_id = ?
             ORDER BY oa.orden'
        );
        $stmt->execute([$objeto['id']]);
        $articulos = $stmt->fetchAll();

        foreach ($articulos as $oa) {
            $cantidad_objeto = $this->evaluar_formula($oa['formula_cantidad']);
            $this->explotar_articulo(
                (int) $oa['articulo_id'],
                $cantidad_objeto,
                $objeto['nombre'] . ' (pos. ' . $posicion . ')',
                $oa['articulo_nombre']
            );
        }
    }

    private function explotar_articulo(
        int $articulo_id,
        float $cantidad_padre,
        string $origen_objeto,
        string $origen_articulo,
        int $profundidad = 0
    ): void {
        // Protección contra recursión infinita
        $key = $articulo_id . '_' . $profundidad;
        if ($profundidad > 10 || isset($this->visitados[$key])) return;
        $this->visitados[$key] = true;

        $stmt = $this->db->prepare(
            'SELECT ac.*,
                    i.numero_parte, i.nombre as item_nombre, i.unidad_medida, i.zona,
                    a.codigo as sub_codigo, a.nombre as sub_nombre
             FROM articulo_componentes ac
             LEFT JOIN items i ON i.id = ac.item_id
             LEFT JOIN articulos a ON a.id = ac.sub_articulo_id
             WHERE ac.articulo_id = ?
             ORDER BY ac.orden'
        );
        $stmt->execute([$articulo_id]);
        $componentes = $stmt->fetchAll();

        foreach ($componentes as $comp) {
            $cantidad_comp = $this->evaluar_formula($comp['formula_cantidad']) * $cantidad_padre;

            if ($comp['item_id']) {
                // Es ítem base → agregar a líneas
                $this->lineas[] = [
                    'item_id'         => (int) $comp['item_id'],
                    'numero_parte'    => $comp['numero_parte'],
                    'nombre'          => $comp['item_nombre'],
                    'unidad_medida'   => $comp['unidad_medida'],
                    'zona'            => $comp['zona'],
                    'cantidad'        => $cantidad_comp,
                    'origen_objeto'   => $origen_objeto,
                    'origen_articulo' => $origen_articulo,
                ];
            } elseif ($comp['sub_articulo_id']) {
                // Es sub-artículo → recursión
                $this->explotar_articulo(
                    (int) $comp['sub_articulo_id'],
                    $cantidad_comp,
                    $origen_objeto,
                    $origen_articulo . ' > ' . $comp['sub_nombre'],
                    $profundidad + 1
                );
            }
        }
    }

    /**
     * Evalúa una fórmula de cantidad.
     * Puede ser un número fijo ("2") o una expresión con parámetros ("largo / 1.2").
     * Los parámetros vienen del JSON de configuración del BOM.
     */
    private function evaluar_formula(string $formula): float {
        $formula = trim($formula);

        // Si es solo un número
        if (is_numeric($formula)) return (float) $formula;

        // Reemplazar parámetros conocidos
        $expr = $formula;
        foreach ($this->parametros as $key => $val) {
            if (is_numeric($val)) {
                $expr = str_replace($key, (float) $val, $expr);
            }
        }

        // Evaluar expresión aritmética de forma segura
        // Solo se permiten números, operadores básicos y paréntesis
        if (!preg_match('/^[\d\s\+\-\*\/\.\(\)]+$/', $expr)) {
            return 1.0; // Fórmula no resoluble → cantidad 1 por defecto
        }

        try {
            $resultado = eval("return ($expr);");
            return is_numeric($resultado) ? (float) $resultado : 1.0;
        } catch (Throwable) {
            return 1.0;
        }
    }

    /**
     * Agrupa las líneas por item_id, sumando cantidades.
     * También devuelve el detalle completo sin agrupar para la vista por objeto.
     */
    private function agrupar_lineas(): array {
        $agrupado = [];
        foreach ($this->lineas as $linea) {
            $key = $linea['item_id'];
            if (isset($agrupado[$key])) {
                $agrupado[$key]['cantidad'] += $linea['cantidad'];
            } else {
                $agrupado[$key] = $linea;
            }
        }

        // Ordenar por zona luego por nombre
        usort($agrupado, fn($a, $b) =>
            strcmp($a['zona'], $b['zona']) ?: strcmp($a['nombre'], $b['nombre'])
        );

        return [
            'agrupado' => array_values($agrupado),
            'detalle'  => $this->lineas,
        ];
    }
}
