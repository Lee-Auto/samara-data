<?php
// src/helpers/utils.php

function e(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): never {
    header("Location: $url");
    exit;
}

function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_verify(): void {
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(403);
        die('Token CSRF inválido.');
    }
}

function paginar(int $total, int $por_pagina, int $pagina_actual): array {
    $total_paginas = (int) ceil($total / $por_pagina);
    $pagina_actual = max(1, min($pagina_actual, $total_paginas));
    $offset = ($pagina_actual - 1) * $por_pagina;
    return [
        'total'         => $total,
        'por_pagina'    => $por_pagina,
        'pagina_actual' => $pagina_actual,
        'total_paginas' => $total_paginas,
        'offset'        => $offset,
    ];
}

function formato_cantidad(float $n): string {
    return $n == intval($n) ? number_format($n, 0) : number_format($n, 4, '.', '');
}

function json_decode_safe(string $json, mixed $default = []): mixed {
    $decoded = json_decode($json, true);
    return (json_last_error() === JSON_ERROR_NONE) ? $decoded : $default;
}
