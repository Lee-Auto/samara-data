<?php
// src/models/Item.php
class Item {
    private PDO $db;
    public function __construct() { $this->db = Database::get(); }

    public function listar(string $busqueda = '', string $zona = ''): array {
        $sql = 'SELECT * FROM items WHERE activo = 1';
        $params = [];
        if ($busqueda) { $sql .= ' AND (nombre LIKE ? OR numero_parte LIKE ?)'; $params[] = "%$busqueda%"; $params[] = "%$busqueda%"; }
        if ($zona)     { $sql .= ' AND zona = ?'; $params[] = $zona; }
        $sql .= ' ORDER BY zona, nombre';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function buscar_por_id(int $id): ?array {
        $stmt = $this->db->prepare('SELECT * FROM items WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function crear(array $data, int $user_id): int {
        $stmt = $this->db->prepare(
            'INSERT INTO items (numero_parte, nombre, descripcion, unidad_medida, zona, created_by)
             VALUES (?,?,?,?,?,?)'
        );
        $stmt->execute([$data['numero_parte'], $data['nombre'], $data['descripcion'], $data['unidad_medida'], $data['zona'], $user_id]);
        return (int) $this->db->lastInsertId();
    }

    public function actualizar(int $id, array $data): bool {
        $stmt = $this->db->prepare(
            'UPDATE items SET numero_parte=?, nombre=?, descripcion=?, unidad_medida=?, zona=?, updated_at=NOW() WHERE id=?'
        );
        return $stmt->execute([$data['numero_parte'], $data['nombre'], $data['descripcion'], $data['unidad_medida'], $data['zona'], $id]);
    }

    public function eliminar(int $id): bool {
        $stmt = $this->db->prepare('UPDATE items SET activo = 0 WHERE id = ?');
        return $stmt->execute([$id]);
    }
}

// src/models/Articulo.php
class Articulo {
    private PDO $db;
    public function __construct() { $this->db = Database::get(); }

    public function listar(string $busqueda = ''): array {
        $sql = 'SELECT * FROM articulos WHERE activo = 1';
        $params = [];
        if ($busqueda) { $sql .= ' AND (nombre LIKE ? OR codigo LIKE ?)'; $params[] = "%$busqueda%"; $params[] = "%$busqueda%"; }
        $sql .= ' ORDER BY nombre';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function buscar_por_id(int $id): ?array {
        $stmt = $this->db->prepare('SELECT * FROM articulos WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function obtener_componentes(int $articulo_id): array {
        $stmt = $this->db->prepare(
            'SELECT ac.*, i.nombre as item_nombre, i.numero_parte, i.unidad_medida, i.zona,
                    a.nombre as sub_nombre, a.codigo as sub_codigo
             FROM articulo_componentes ac
             LEFT JOIN items i ON i.id = ac.item_id
             LEFT JOIN articulos a ON a.id = ac.sub_articulo_id
             WHERE ac.articulo_id = ? ORDER BY ac.orden'
        );
        $stmt->execute([$articulo_id]);
        return $stmt->fetchAll();
    }

    public function crear(array $data, int $user_id): int {
        $stmt = $this->db->prepare('INSERT INTO articulos (codigo, nombre, descripcion, created_by) VALUES (?,?,?,?)');
        $stmt->execute([$data['codigo'], $data['nombre'], $data['descripcion'], $user_id]);
        return (int) $this->db->lastInsertId();
    }

    public function actualizar(int $id, array $data): bool {
        $stmt = $this->db->prepare('UPDATE articulos SET codigo=?, nombre=?, descripcion=?, updated_at=NOW() WHERE id=?');
        return $stmt->execute([$data['codigo'], $data['nombre'], $data['descripcion'], $id]);
    }

    public function guardar_componentes(int $articulo_id, array $componentes): void {
        $this->db->prepare('DELETE FROM articulo_componentes WHERE articulo_id = ?')->execute([$articulo_id]);
        $stmt = $this->db->prepare(
            'INSERT INTO articulo_componentes (articulo_id, item_id, sub_articulo_id, formula_cantidad, notas, orden)
             VALUES (?,?,?,?,?,?)'
        );
        foreach ($componentes as $i => $comp) {
            $item_id = !empty($comp['item_id']) ? (int)$comp['item_id'] : null;
            $sub_id  = !empty($comp['sub_articulo_id']) ? (int)$comp['sub_articulo_id'] : null;
            $stmt->execute([$articulo_id, $item_id, $sub_id, $comp['formula_cantidad'] ?? '1', $comp['notas'] ?? '', $i]);
        }
    }

    public function eliminar(int $id): bool {
        $stmt = $this->db->prepare('UPDATE articulos SET activo = 0 WHERE id = ?');
        return $stmt->execute([$id]);
    }
}

// src/models/Objeto.php
class Objeto {
    private PDO $db;
    public function __construct() { $this->db = Database::get(); }

    public function listar(): array {
        return $this->db->query('SELECT * FROM objetos WHERE activo = 1 ORDER BY letra_config')->fetchAll();
    }

    public function buscar_por_id(int $id): ?array {
        $stmt = $this->db->prepare('SELECT * FROM objetos WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function buscar_por_letra(string $letra): ?array {
        $stmt = $this->db->prepare('SELECT * FROM objetos WHERE letra_config = ? AND activo = 1 LIMIT 1');
        $stmt->execute([strtoupper($letra)]);
        return $stmt->fetch() ?: null;
    }

    public function obtener_articulos(int $objeto_id): array {
        $stmt = $this->db->prepare(
            'SELECT oa.*, a.nombre as articulo_nombre, a.codigo
             FROM objeto_articulos oa
             JOIN articulos a ON a.id = oa.articulo_id
             WHERE oa.objeto_id = ? ORDER BY oa.orden'
        );
        $stmt->execute([$objeto_id]);
        return $stmt->fetchAll();
    }

    public function crear(array $data, int $user_id): int {
        $stmt = $this->db->prepare('INSERT INTO objetos (letra_config, nombre, descripcion, tipo, created_by) VALUES (?,?,?,?,?)');
        $stmt->execute([strtoupper($data['letra_config']), $data['nombre'], $data['descripcion'], $data['tipo'], $user_id]);
        return (int) $this->db->lastInsertId();
    }

    public function actualizar(int $id, array $data): bool {
        $stmt = $this->db->prepare('UPDATE objetos SET letra_config=?, nombre=?, descripcion=?, tipo=?, updated_at=NOW() WHERE id=?');
        return $stmt->execute([strtoupper($data['letra_config']), $data['nombre'], $data['descripcion'], $data['tipo'], $id]);
    }

    public function guardar_articulos(int $objeto_id, array $articulos): void {
        $this->db->prepare('DELETE FROM objeto_articulos WHERE objeto_id = ?')->execute([$objeto_id]);
        $stmt = $this->db->prepare('INSERT INTO objeto_articulos (objeto_id, articulo_id, formula_cantidad, notas, orden) VALUES (?,?,?,?,?)');
        foreach ($articulos as $i => $art) {
            $stmt->execute([$objeto_id, (int)$art['articulo_id'], $art['formula_cantidad'] ?? '1', $art['notas'] ?? '', $i]);
        }
    }

    public function eliminar(int $id): bool {
        $stmt = $this->db->prepare('UPDATE objetos SET activo = 0 WHERE id = ?');
        return $stmt->execute([$id]);
    }
}

// src/models/Bom.php
class Bom {
    private PDO $db;
    public function __construct() { $this->db = Database::get(); }

    public function listar(int $user_id = 0, string $busqueda = ''): array {
        $sql = 'SELECT b.*, u.nombre as creado_por FROM boms b LEFT JOIN usuarios u ON u.id = b.created_by WHERE 1=1';
        $params = [];
        if ($busqueda) { $sql .= ' AND (b.nombre LIKE ? OR b.codigo_config LIKE ?)'; $params[] = "%$busqueda%"; $params[] = "%$busqueda%"; }
        $sql .= ' ORDER BY b.created_at DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function buscar_por_id(int $id): ?array {
        $stmt = $this->db->prepare('SELECT b.*, u.nombre as creado_por FROM boms b LEFT JOIN usuarios u ON u.id = b.created_by WHERE b.id = ? LIMIT 1');
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function obtener_lineas(int $bom_id, string $zona = ''): array {
        $sql = 'SELECT bl.*, i.numero_parte, i.unidad_medida FROM bom_lineas bl JOIN items i ON i.id = bl.item_id WHERE bl.bom_id = ?';
        $params = [$bom_id];
        if ($zona) { $sql .= ' AND bl.zona = ?'; $params[] = $zona; }
        $sql .= ' ORDER BY bl.zona, bl.origen_objeto, bl.cantidad DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function crear(array $data, int $user_id): int {
        $stmt = $this->db->prepare(
            'INSERT INTO boms (nombre, codigo_config, parametros_json, notas, estado, version, bom_padre_id, created_by)
             VALUES (?,?,?,?,?,?,?,?)'
        );
        $stmt->execute([
            $data['nombre'], $data['codigo_config'],
            $data['parametros_json'] ?? null, $data['notas'] ?? null,
            $data['estado'] ?? 'borrador', $data['version'] ?? 1,
            $data['bom_padre_id'] ?? null, $user_id
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function guardar_lineas(int $bom_id, array $lineas): void {
        $this->db->prepare('DELETE FROM bom_lineas WHERE bom_id = ?')->execute([$bom_id]);
        $stmt = $this->db->prepare(
            'INSERT INTO bom_lineas (bom_id, item_id, cantidad_calculada, zona, origen_objeto, origen_articulo)
             VALUES (?,?,?,?,?,?)'
        );
        foreach ($lineas as $l) {
            $stmt->execute([$bom_id, $l['item_id'], $l['cantidad'], $l['zona'], $l['origen_objeto'], $l['origen_articulo']]);
        }
    }

    public function crear_version(int $bom_id, int $user_id): int {
        $original = $this->buscar_por_id($bom_id);
        if (!$original) return 0;
        $nueva_version = $original['version'] + 1;
        $nuevo_id = $this->crear([
            'nombre'          => $original['nombre'] . ' v' . $nueva_version,
            'codigo_config'   => $original['codigo_config'],
            'parametros_json' => $original['parametros_json'],
            'notas'           => $original['notas'],
            'estado'          => 'borrador',
            'version'         => $nueva_version,
            'bom_padre_id'    => $bom_id,
        ], $user_id);
        // Copiar líneas del original
        $lineas = $this->obtener_lineas($bom_id);
        foreach ($lineas as &$l) { $l['cantidad'] = $l['cantidad_calculada']; }
        $this->guardar_lineas($nuevo_id, $lineas);
        return $nuevo_id;
    }

    public function actualizar_estado(int $id, string $estado): bool {
        $stmt = $this->db->prepare('UPDATE boms SET estado = ?, updated_at = NOW() WHERE id = ?');
        return $stmt->execute([$estado, $id]);
    }

    public function historial_versiones(int $bom_id): array {
        // Sube hasta el padre raíz
        $raiz = $this->buscar_por_id($bom_id);
        while ($raiz && $raiz['bom_padre_id']) {
            $raiz = $this->buscar_por_id($raiz['bom_padre_id']);
        }
        if (!$raiz) return [];
        // Baja recursivamente
        return $this->db->prepare(
            'WITH RECURSIVE hist AS (
                SELECT * FROM boms WHERE id = ?
                UNION ALL
                SELECT b.* FROM boms b JOIN hist h ON b.bom_padre_id = h.id
             )
             SELECT h.*, u.nombre as creado_por FROM hist h LEFT JOIN usuarios u ON u.id = h.created_by ORDER BY h.version'
        )->execute([$raiz['id']]) ? $this->db->query(
            'WITH RECURSIVE hist AS (
                SELECT * FROM boms WHERE id = ' . $raiz['id'] . '
                UNION ALL
                SELECT b.* FROM boms b JOIN hist h ON b.bom_padre_id = h.id
             )
             SELECT h.*, u.nombre as creado_por FROM hist h LEFT JOIN usuarios u ON u.id = h.created_by ORDER BY h.version'
        )->fetchAll() : [];
    }
}
