<?php
// src/models/Usuario.php

class Usuario {
    private PDO $db;
    public function __construct() { $this->db = Database::get(); }

    public function buscar_por_email(string $email): ?array {
        $stmt = $this->db->prepare('SELECT * FROM usuarios WHERE email = ? AND activo = 1 LIMIT 1');
        $stmt->execute([$email]);
        return $stmt->fetch() ?: null;
    }

    public function verificar_password(string $password, string $hash): bool {
        return password_verify($password, $hash);
    }

    public function listar(): array {
        return $this->db->query('SELECT id, nombre, email, rol, activo, created_at FROM usuarios ORDER BY nombre')->fetchAll();
    }

    public function crear(string $nombre, string $email, string $password, string $rol): bool {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare('INSERT INTO usuarios (nombre, email, password_hash, rol) VALUES (?,?,?,?)');
        return $stmt->execute([$nombre, $email, $hash, $rol]);
    }

    public function actualizar_password(int $id, string $nueva): bool {
        $hash = password_hash($nueva, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare('UPDATE usuarios SET password_hash = ? WHERE id = ?');
        return $stmt->execute([$hash, $id]);
    }
}
