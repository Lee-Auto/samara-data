<?php
// views/layout.php — Incluir con: include __DIR__ . '/../views/layout.php';
// Variables esperadas: $titulo (string), $contenido (string capturado con ob_start/ob_get_clean)
$user = auth_user();
$flash = flash_html();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($titulo ?? 'Samara Data') ?> — <?= APP_NAME ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
:root { --sidebar-w: 230px; }
body { background: #f8f9fa; font-size: 14px; }
.sidebar { width: var(--sidebar-w); min-height: 100vh; background: #1a1a2e; position: fixed; top: 0; left: 0; z-index: 100; display: flex; flex-direction: column; }
.sidebar-brand { padding: 20px 20px 12px; color: #fff; font-size: 18px; font-weight: 600; border-bottom: 1px solid rgba(255,255,255,.1); }
.sidebar-brand small { display: block; font-size: 11px; font-weight: 400; color: rgba(255,255,255,.45); margin-top: 2px; }
.sidebar-nav { padding: 12px 0; flex: 1; }
.nav-section { font-size: 10px; text-transform: uppercase; letter-spacing: .08em; color: rgba(255,255,255,.35); padding: 16px 20px 6px; }
.sidebar .nav-link { color: rgba(255,255,255,.7); padding: 8px 20px; border-radius: 0; display: flex; align-items: center; gap: 10px; transition: all .15s; }
.sidebar .nav-link:hover, .sidebar .nav-link.active { background: rgba(255,255,255,.1); color: #fff; }
.sidebar .nav-link i { font-size: 16px; width: 20px; }
.main { margin-left: var(--sidebar-w); min-height: 100vh; }
.topbar { background: #fff; border-bottom: 1px solid #e9ecef; padding: 12px 24px; display: flex; align-items: center; justify-content: space-between; }
.topbar-title { font-size: 16px; font-weight: 600; color: #1a1a2e; margin: 0; }
.page-content { padding: 24px; }
.card { border: 1px solid #e9ecef; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,.04); }
.card-header { background: #fff; border-bottom: 1px solid #e9ecef; font-weight: 600; padding: 14px 20px; }
.btn-primary { background: #1a1a2e; border-color: #1a1a2e; }
.btn-primary:hover { background: #2d2d4e; border-color: #2d2d4e; }
.badge-zona { font-size: 11px; padding: 3px 8px; border-radius: 20px; font-weight: 500; }
.badge-Z1 { background:#dbeafe; color:#1e40af; }
.badge-Z2 { background:#dcfce7; color:#166534; }
.badge-Z3 { background:#fef9c3; color:#854d0e; }
.badge-Z4 { background:#ffe4e6; color:#9f1239; }
.badge-Z5 { background:#f3e8ff; color:#6b21a8; }
.badge-Z6 { background:#e5e7eb; color:#374151; }
.table thead th { font-size: 12px; text-transform: uppercase; letter-spacing: .04em; color: #6b7280; font-weight: 500; border-bottom: 1px solid #e9ecef; }
</style>
</head>
<body>

<div class="sidebar">
  <div class="sidebar-brand">
    <i class="bi bi-layers-half me-2"></i><?= APP_NAME ?>
    <small>v<?= APP_VERSION ?></small>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section">General</div>
    <a href="/index.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : '' ?>">
      <i class="bi bi-house"></i> Dashboard
    </a>

    <div class="nav-section">Catálogo</div>
    <a href="/items.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], 'item') ? 'active' : '' ?>">
      <i class="bi bi-box"></i> Ítems base
    </a>
    <a href="/articulos.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], 'articulo') ? 'active' : '' ?>">
      <i class="bi bi-boxes"></i> Artículos
    </a>
    <a href="/objetos.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], 'objeto') ? 'active' : '' ?>">
      <i class="bi bi-building"></i> Objetos
    </a>

    <div class="nav-section">BOMs</div>
    <a href="/boms.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], 'bom') ? 'active' : '' ?>">
      <i class="bi bi-table"></i> Mis BOMs
    </a>
    <a href="/bom_nuevo.php" class="nav-link">
      <i class="bi bi-plus-circle"></i> Nuevo BOM
    </a>

    <?php if (is_admin()): ?>
    <div class="nav-section">Admin</div>
    <a href="/usuarios.php" class="nav-link <?= str_contains($_SERVER['PHP_SELF'], 'usuario') ? 'active' : '' ?>">
      <i class="bi bi-people"></i> Usuarios
    </a>
    <?php endif; ?>
  </nav>
  <div class="p-3 border-top border-secondary" style="border-color:rgba(255,255,255,.1)!important">
    <div class="text-white-50 small mb-2"><?= e($user['nombre']) ?></div>
    <a href="/logout.php" class="btn btn-sm btn-outline-light w-100"><i class="bi bi-box-arrow-right me-1"></i>Salir</a>
  </div>
</div>

<div class="main">
  <div class="topbar">
    <h1 class="topbar-title"><?= e($titulo ?? '') ?></h1>
    <div class="d-flex align-items-center gap-3">
      <span class="badge bg-secondary"><?= e($user['rol']) ?></span>
    </div>
  </div>
  <div class="page-content">
    <?= $flash ?>
    <?= $contenido ?>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
