<?php
require_once __DIR__ . '/src/bootstrap.php';
auth_check();
if (!is_editor()) { flash_set('error','Sin permisos.'); redirect('/boms.php'); }

$modelo_model = new ModeloCasa();
$modelos = $modelo_model->listar();
$modelo_id = (int)($_GET['modelo'] ?? 0);
$modelo_sel = $modelo_id ? $modelo_model->buscar_por_id($modelo_id) : null;
$grupos = $modelo_sel ? $modelo_model->obtener_grupos($modelo_id) : [];

if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    $nombre=$_POST['nombre']??''; $notas=$_POST['notas']??''; $params_raw=$_POST['parametros']??''; $modo=$_POST['modo']??'modelo';
    $parametros=[];
    foreach (explode("\n",$params_raw) as $linea) {
        $linea=trim($linea);
        if (strpos($linea,'=')!==false) { [$k,$v]=array_map('trim',explode('=',$linea,2)); if($k!==''&&is_numeric($v)) $parametros[$k]=(float)$v; }
    }
    if (empty(trim($nombre))) { flash_set('error','El nombre es requerido.'); redirect('/bom_nuevo.php'.($modelo_id?"?modelo=$modelo_id":'')); }
    $engine=new BomEngine(Database::get(),$parametros);
    if ($modo==='modelo'&&$modelo_id) {
        $opciones_ids=[];
        foreach ($_POST['opcion']??[] as $oid) $opciones_ids[]=(int)$oid;
        $resultado=$engine->explotar_desde_modelo($modelo_id,$opciones_ids);
        $codigo=$resultado['codigo']??'';
    } else {
        $codigo=strtoupper(trim($_POST['codigo_config']??''));
        if (empty($codigo)) { flash_set('error','Código requerido.'); redirect('/bom_nuevo.php'); }
        $resultado=$engine->explotar($codigo);
    }
    if (empty($resultado['agrupado'])) { flash_set('warning','Sin resultados. Verifica configuración de objetos.'); redirect('/bom_nuevo.php'.($modelo_id?"?modelo=$modelo_id":'')); }
    $bom_model=new Bom();
    $bom_id=$bom_model->crear(['nombre'=>trim($nombre),'codigo_config'=>$codigo,'parametros_json'=>!empty($parametros)?json_encode($parametros):null,'notas'=>trim($notas),'estado'=>'borrador','version'=>1],auth_user()['id']);
    $bom_model->guardar_lineas($bom_id,$resultado['agrupado']);
    flash_set('success','BOM generado con '.count($resultado['agrupado']).' ítems.');
    redirect('/bom_ver.php?id='.$bom_id);
}

$obj_model = new Objeto(); $objs_all = $obj_model->listar();
ob_start();
?>
<ul class="nav nav-tabs mb-4">
  <li class="nav-item"><a class="nav-link active" href="#modo-modelo" data-bs-toggle="tab"><i class="bi bi-house me-1"></i>Desde modelo</a></li>
  <li class="nav-item"><a class="nav-link" href="#modo-codigo" data-bs-toggle="tab"><i class="bi bi-code me-1"></i>Código manual</a></li>
</ul>
<div class="tab-content">
<div class="tab-pane fade show active" id="modo-modelo">
<div class="row g-4">
<div class="col-md-8">
<form method="POST">
<input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
<input type="hidden" name="modo" value="modelo">
<div class="card mb-3">
  <div class="card-header">1. Elige el modelo</div>
  <div class="card-body">
    <div class="row g-2">
    <?php foreach($modelos as $m):?>
    <div class="col-md-4">
      <a href="/bom_nuevo.php?modelo=<?= $m['id'] ?>" class="d-block border rounded p-3 text-center text-decoration-none <?= $modelo_id==$m['id']?'border-primary bg-primary bg-opacity-10':'' ?>">
        <div class="fw-bold"><?= e($m['nombre']) ?></div>
        <div class="text-muted small"><?= e($m['codigo']) ?></div>
      </a>
    </div>
    <?php endforeach;?>
    <?php if(empty($modelos)):?><div class="col-12 text-muted text-center py-3">Sin modelos. <a href="/modelos.php?accion=editar">Crear primero</a></div><?php endif;?>
    </div>
  </div>
</div>
<?php if($modelo_sel&&!empty($grupos)):?>
<div class="card mb-3">
  <div class="card-header">2. Configura las opciones</div>
  <div class="card-body">
  <?php foreach($grupos as $g):?>
  <div class="mb-4">
    <div class="fw-medium mb-2"><?= e($g['nombre']) ?><?php if($g['requerido']):?><span class="text-danger ms-1 small">*</span><?php endif;?></div>
    <div class="d-flex flex-wrap gap-2">
    <?php foreach($g['opciones'] as $op):?>
    <label class="opcion-btn">
      <input type="radio" name="opcion[<?= $g['id'] ?>]" value="<?= $op['id'] ?>" <?= $op['es_default']?'checked':'' ?> <?= $g['requerido']?'required':'' ?> class="d-none opcion-radio">
      <span class="btn btn-sm btn-outline-secondary opcion-label"><?= e($op['nombre']) ?></span>
    </label>
    <?php endforeach;?>
    </div>
  </div>
  <?php endforeach;?>
  </div>
</div>
<?php elseif($modelo_sel):?>
<div class="alert alert-warning">Sin opciones configuradas. <a href="/modelos.php?accion=opciones&id=<?= $modelo_id ?>">Configurar ahora</a></div>
<?php endif;?>
<?php if($modelo_sel):?>
<div class="card mb-3">
  <div class="card-header">3. Datos del BOM</div>
  <div class="card-body">
    <div class="mb-3"><label class="form-label fw-medium">Nombre *</label><input type="text" name="nombre" class="form-control" placeholder="Ej: Casa Wilkinson — Lote 12" required></div>
    <div class="mb-3"><label class="form-label fw-medium">Parámetros</label><textarea name="parametros" class="form-control font-monospace" rows="3" placeholder="largo=6.5&#10;ancho=4.2&#10;alto=2.7"></textarea></div>
    <div class="mb-3"><label class="form-label fw-medium">Notas</label><textarea name="notas" class="form-control" rows="2"></textarea></div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-lightning me-1"></i>Generar BOM</button>
  </div>
</div>
<?php endif;?>
</form>
</div>
<?php if($modelo_sel):?>
<div class="col-md-4">
  <div class="card">
    <div class="card-header">Posiciones del modelo</div>
    <table class="table table-sm mb-0">
      <thead><tr><th>#</th><th>Posición</th><th>Default</th></tr></thead>
      <tbody>
      <?php $pl=json_decode($modelo_sel['posiciones_json'],true)??[]; $dl=json_decode($modelo_sel['objetos_default_json'],true)??[];
      foreach($pl as $k=>$v):?>
      <tr><td class="text-muted"><?= $k ?></td><td><?= e($v) ?></td><td><kbd><?= e($dl[$k]??'?') ?></kbd></td></tr>
      <?php endforeach;?>
      </tbody>
    </table>
  </div>
</div>
<?php endif;?>
</div>
</div>
<div class="tab-pane fade" id="modo-codigo">
<div class="row g-4">
<div class="col-md-7">
  <div class="card">
    <div class="card-header">Configurar por código</div>
    <div class="card-body">
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
        <input type="hidden" name="modo" value="codigo">
        <div class="mb-3"><label class="form-label fw-medium">Nombre *</label><input type="text" name="nombre" class="form-control" required></div>
        <div class="mb-3"><label class="form-label fw-medium">Código *</label>
          <input type="text" name="codigo_config" class="form-control font-monospace text-uppercase" placeholder="AABC" oninput="previewCodigo(this.value)" autocomplete="off">
          <div id="codigo_preview" class="mt-2 d-flex flex-wrap gap-2"></div>
        </div>
        <div class="mb-3"><label class="form-label fw-medium">Parámetros</label><textarea name="parametros" class="form-control font-monospace" rows="3" placeholder="largo=6.5&#10;ancho=4.2"></textarea></div>
        <div class="mb-3"><label class="form-label fw-medium">Notas</label><textarea name="notas" class="form-control" rows="2"></textarea></div>
        <button type="submit" class="btn btn-primary"><i class="bi bi-lightning me-1"></i>Generar BOM</button>
      </form>
    </div>
  </div>
</div>
<div class="col-md-5">
  <div class="card">
    <div class="card-header">Objetos disponibles</div>
    <table class="table table-sm mb-0">
      <thead><tr><th>Letra</th><th>Nombre</th></tr></thead>
      <tbody><?php foreach($objs_all as $o):?><tr><td><kbd><?= e($o['letra_config']) ?></kbd></td><td class="small"><?= e($o['nombre']) ?></td></tr><?php endforeach;?></tbody>
    </table>
  </div>
</div>
</div>
</div>
</div>
<style>.opcion-radio:checked+.opcion-label{background:#1a1a2e;color:#fff;border-color:#1a1a2e}.opcion-label{cursor:pointer;transition:all .15s}</style>
<script>
const objMap=<?= json_encode(array_column($objs_all,'nombre','letra_config')) ?>;
function previewCodigo(v){const d=document.getElementById('codigo_preview');if(!d||!v){if(d)d.innerHTML='';return;}v=v.toUpperCase();d.innerHTML=[...v].map((l,i)=>{const n=objMap[l];return`<span class="badge ${n?'bg-success':'bg-danger'}">${i+1}:${l} ${n||'?'}</span>`;}).join('');}
</script>
<?php
$contenido=ob_get_clean();
$titulo='Nuevo BOM';
require_once __DIR__ . '/views/layout.php';
