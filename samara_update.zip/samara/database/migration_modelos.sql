-- ============================================================
-- SAMARA DATA — Migración: Modelos y Opciones
-- Ejecutar en phpMyAdmin o mysql CLI
-- ============================================================

-- Modelos de casa (Studio, One Bedroom, etc.)
CREATE TABLE IF NOT EXISTS modelos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(50) NOT NULL UNIQUE,
    nombre VARCHAR(200) NOT NULL,
    descripcion TEXT,
    -- Posiciones del modelo en formato JSON: {"1":"descripcion","2":"descripcion"...}
    posiciones_json TEXT NOT NULL DEFAULT '{}',
    -- Objetos por defecto para cada posición: {"1":"A","2":"A","3":"B"}
    objetos_default_json TEXT NOT NULL DEFAULT '{}',
    activo TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Grupos de opciones (Color, Cocina, Paneles solares, etc.)
CREATE TABLE IF NOT EXISTS opcion_grupos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    modelo_id INT NOT NULL,
    nombre VARCHAR(200) NOT NULL,
    descripcion TEXT,
    tipo ENUM('exclusivo','toggle') NOT NULL DEFAULT 'exclusivo',
    requerido TINYINT(1) NOT NULL DEFAULT 1,
    orden INT NOT NULL DEFAULT 0,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    FOREIGN KEY (modelo_id) REFERENCES modelos(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Opciones dentro de cada grupo
CREATE TABLE IF NOT EXISTS opciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    grupo_id INT NOT NULL,
    nombre VARCHAR(200) NOT NULL,
    descripcion TEXT,
    es_default TINYINT(1) NOT NULL DEFAULT 0,
    orden INT NOT NULL DEFAULT 0,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    FOREIGN KEY (grupo_id) REFERENCES opcion_grupos(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Efectos de cada opción sobre el BOM
-- Tipo "agregar_item": agrega cantidad de un ítem
-- Tipo "cambiar_objeto": en la posición X usa el objeto Y en lugar del default
CREATE TABLE IF NOT EXISTS opcion_efectos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    opcion_id INT NOT NULL,
    tipo ENUM('agregar_item','cambiar_objeto') NOT NULL,
    -- Para agregar_item:
    item_id INT NULL,
    formula_cantidad VARCHAR(255) NULL,
    -- Para cambiar_objeto:
    posicion VARCHAR(50) NULL,
    objeto_id INT NULL,
    FOREIGN KEY (opcion_id) REFERENCES opciones(id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE SET NULL,
    FOREIGN KEY (objeto_id) REFERENCES objetos(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Datos de ejemplo
INSERT INTO modelos (codigo, nombre, descripcion, posiciones_json, objetos_default_json) VALUES
('STUDIO', 'Studio', 'Casa modelo Studio — configuración básica',
 '{"1":"Pared frontal","2":"Pared trasera","3":"Pared lateral izquierda","4":"Pared lateral derecha"}',
 '{"1":"A","2":"A","3":"A","4":"A"}')
ON DUPLICATE KEY UPDATE codigo=codigo;
