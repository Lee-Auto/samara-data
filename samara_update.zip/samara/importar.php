<?php
require_once __DIR__ . '/src/bootstrap.php';
auth_check();
if (!is_editor()) { flash_set('error','Sin permisos.'); redirect('/index.php'); }

// Procesar subida
if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    if (empty($_FILES['archivo']['tmp_name'])) { flash_set('error','Selecciona un archivo Excel.'); redirect('/importar.php'); }

    $ext = strtolower(pathinfo($_FILES['archivo']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext,['xlsx','xls'])) { flash_set('error','Solo se aceptan archivos .xlsx o .xls'); redirect('/importar.php'); }

    // Leer Excel con librería nativa (sin dependencias)
    $tmp = $_FILES['archivo']['tmp_name'];
    $resultado = importar_excel($tmp);
    flash_set('success', "Importación completa: {$resultado['items']} ítems, {$resultado['articulos']} artículos procesados.");
    redirect('/importar.php');
}

function importar_excel(string $path): array {
    $db = Database::get();
    $user_id = auth_user()['id'];
    $counts = ['items'=>0,'articulos'=>0,'objetos'=>0,'errores'=>[]];

    // Descomprimir XLSX (es un ZIP)
    $zip = new ZipArchive();
    if ($zip->open($path)===false) return $counts;

    // Leer strings compartidos
    $strings = [];
    $ssXml = $zip->getFromName('xl/sharedStrings.xml');
    if ($ssXml) {
        $ss = simplexml_load_string($ssXml);
        foreach ($ss->si as $si) {
            $t = '';
            if (isset($si->t)) $t = (string)$si->t;
            elseif (isset($si->r)) foreach ($si->r as $r) if (isset($r->t)) $t .= (string)$r->t;
            $strings[] = $t;
        }
    }

    // Leer hoja 1 = ítems, hoja 2 = artículos
    for ($sheet=1; $sheet<=2; $sheet++) {
        $sheetXml = $zip->getFromName("xl/worksheets/sheet{$sheet}.xml");
        if (!$sheetXml) continue;
        $xml = simplexml_load_string($sheetXml);
        $rows = [];
        foreach ($xml->sheetData->row as $row) {
            $rowData = [];
            foreach ($row->c as $cell) {
                $val = '';
                $t = (string)($cell['t']??'');
                $v = isset($cell->v) ? (string)$cell->v : '';
                if ($t==='s' && isset($strings[(int)$v])) $val = $strings[(int)$v];
                elseif ($t==='inlineStr') $val = isset($cell->is->t) ? (string)$cell->is->t : '';
                else $val = $v;
                $rowData[] = trim($val);
            }
            $rows[] = $rowData;
        }
        if (count($rows)<2) continue;
        array_shift($rows); // quitar cabecera

        if ($sheet===1) {
            // Ítems: numero_parte | nombre | descripcion | unidad_medida | zona
            foreach ($rows as $r) {
                if (empty($r[0])||empty($r[1])) continue;
                $np=trim($r[0]); $nom=trim($r[1]); $desc=trim($r[2]??''); $um=trim($r[3]??'pza'); $zona=strtoupper(trim($r[4]??'Z1'));
                if (!in_array($zona,['Z1','Z2','Z3','Z4','Z5','Z6'])) $zona='Z1';
                $stmt=$db->prepare('INSERT INTO items (numero_parte,nombre,descripcion,unidad_medida,zona,created_by) VALUES (?,?,?,?,?,?) ON DUPLICATE KEY UPDATE nombre=VALUES(nombre),descripcion=VALUES(descripcion),unidad_medida=VALUES(unidad_medida),zona=VALUES(zona)');
                $stmt->execute([$np,$nom,$desc,$um,$zona,$user_id]);
                $counts['items']++;
            }
        } elseif ($sheet===2) {
            // Artículos: codigo | nombre | descripcion
            foreach ($rows as $r) {
                if (empty($r[0])||empty($r[1])) continue;
                $cod=trim($r[0]); $nom=trim($r[1]); $desc=trim($r[2]??'');
                $stmt=$db->prepare('INSERT INTO articulos (codigo,nombre,descripcion,created_by) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE nombre=VALUES(nombre),descripcion=VALUES(descripcion)');
                $stmt->execute([$cod,$nom,$desc,$user_id]);
                $counts['articulos']++;
            }
        }
    }
    $zip->close();
    return $counts;
}

ob_start(); ?>
<div class="row g-4">
  <div class="col-md-7">
    <div class="card mb-4">
      <div class="card-header">Importar catálogo desde Excel</div>
      <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <div class="mb-4">
            <label class="form-label fw-medium">Archivo Excel (.xlsx)</label>
            <input type="file" name="archivo" class="form-control" accept=".xlsx,.xls" required>
            <div class="form-text">El archivo debe seguir el formato de la plantilla (ver abajo)</div>
          </div>
          <button type="submit" class="btn btn-primary">
            <i class="bi bi-upload me-1"></i>Importar
          </button>
          <a href="/plantilla_importacion.php" class="btn btn-outline-secondary ms-2">
            <i class="bi bi-download me-1"></i>Descargar plantilla
          </a>
        </form>
      </div>
    </div>

    <div class="card">
      <div class="card-header">Formato esperado</div>
      <div class="card-body">
        <div class="fw-medium small mb-2">Hoja 1 — Ítems base</div>
        <div class="table-responsive mb-3">
          <table class="table table-sm table-bordered mb-0">
            <thead class="table-light"><tr><th>numero_parte</th><th>nombre</th><th>descripcion</th><th>unidad_medida</th><th>zona</th></tr></thead>
            <tbody>
              <tr><td>ACE-001</td><td>Panel acero 1.2m</td><td>Panel estructural</td><td>m2</td><td>Z1</td></tr>
              <tr><td>PIN-001</td><td>Pintura Bone White</td><td>4 litros</td><td>lt</td><td>Z4</td></tr>
            </tbody>
          </table>
        </div>
        <div class="fw-medium small mb-2">Hoja 2 — Artículos</div>
        <div class="table-responsive">
          <table class="table table-sm table-bordered mb-0">
            <thead class="table-light"><tr><th>codigo</th><th>nombre</th><th>descripcion</th></tr></thead>
            <tbody>
              <tr><td>VENT-01</td><td>Ventana tipo 1</td><td>Marco + vidrio fijo</td></tr>
              <tr><td>PUER-01</td><td>Puerta tipo A</td><td>Puerta metálica 90cm</td></tr>
            </tbody>
          </table>
        </div>
        <div class="alert alert-info mt-3 mb-0 small">
          <i class="bi bi-info-circle me-1"></i>
          La primera fila de cada hoja es el encabezado y se ignora. Los registros existentes con el mismo número de parte o código se actualizan automáticamente.
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-5">
    <div class="card">
      <div class="card-header">Zonas disponibles</div>
      <table class="table table-sm mb-0">
        <thead><tr><th>Clave</th><th>Descripción</th></tr></thead>
        <tbody>
        <?php foreach(ZONAS as $k=>$v):?>
        <tr><td><span class="badge-zona badge-<?= $k ?>"><?= $k ?></span></td><td class="small"><?= $v ?></td></tr>
        <?php endforeach;?>
        </tbody>
      </table>
    </div>
    <div class="card mt-3">
      <div class="card-header">Unidades de medida</div>
      <div class="card-body">
        <div class="d-flex flex-wrap gap-2">
          <?php foreach(UNIDADES as $u):?>
          <span class="badge bg-light text-dark"><?= $u ?></span>
          <?php endforeach;?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php
$contenido = ob_get_clean();
$titulo = 'Importar catálogo';
require_once __DIR__ . '/views/layout.php';
