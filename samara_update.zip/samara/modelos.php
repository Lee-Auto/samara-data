<?php
require_once __DIR__ . '/src/bootstrap.php';
auth_check();

$model = new ModeloCasa();
$obj_model = new Objeto();
$item_model = new Item();
$accion = $_GET['accion'] ?? 'listar';
$id = (int)($_GET['id'] ?? 0);

// ── GUARDAR MODELO ──
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['guardar_modelo'])) {
    csrf_verify();
    if (!is_editor()) { flash_set('error','Sin permisos.'); redirect('/modelos.php'); }
    $posiciones = [];
    $defaults = [];
    $pos_nombres = $_POST['pos_nombre'] ?? [];
    $pos_defaults = $_POST['pos_default'] ?? [];
    foreach ($pos_nombres as $i => $nombre) {
        if (trim($nombre)==='') continue;
        $posiciones[$i+1] = trim($nombre);
        $defaults[$i+1] = strtoupper(trim($pos_defaults[$i] ?? 'A'));
    }
    $data = [
        'codigo'              => trim($_POST['codigo']??''),
        'nombre'              => trim($_POST['nombre']??''),
        'descripcion'         => trim($_POST['descripcion']??''),
        'posiciones_json'     => json_encode($posiciones),
        'objetos_default_json'=> json_encode($defaults),
    ];
    if (empty($data['codigo'])||empty($data['nombre'])) { flash_set('error','Código y nombre requeridos.'); redirect('/modelos.php?accion=editar'.($id?"&id=$id":'')); }
    if ($id) { $model->actualizar($id,$data); flash_set('success','Modelo actualizado.'); }
    else { $id=$model->crear($data,auth_user()['id']); flash_set('success','Modelo creado.'); }
    redirect('/modelos.php?accion=opciones&id='.$id);
}

// ── GUARDAR GRUPO ──
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['guardar_grupo'])) {
    csrf_verify();
    $model->guardar_grupo($id, ['nombre'=>trim($_POST['nombre']??''),'tipo'=>$_POST['tipo']??'exclusivo','requerido'=>$_POST['requerido']??1,'orden'=>$_POST['orden']??0,'descripcion'=>trim($_POST['descripcion']??'')]);
    flash_set('success','Grupo guardado.'); redirect('/modelos.php?accion=opciones&id='.$id);
}

// ── GUARDAR OPCIÓN ──
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['guardar_opcion'])) {
    csrf_verify();
    $grupo_id = (int)$_POST['grupo_id'];
    $opcion_id = $model->guardar_opcion($grupo_id, ['nombre'=>trim($_POST['opcion_nombre']??''),'descripcion'=>trim($_POST['opcion_desc']??''),'es_default'=>$_POST['es_default']??0,'orden'=>$_POST['opcion_orden']??0]);
    // Efectos
    $tipos_ef = $_POST['efecto_tipo'] ?? [];
    $items_ef  = $_POST['efecto_item'] ?? [];
    $fmls_ef   = $_POST['efecto_formula'] ?? [];
    $poss_ef   = $_POST['efecto_posicion'] ?? [];
    $objs_ef   = $_POST['efecto_objeto'] ?? [];
    $efectos = [];
    foreach ($tipos_ef as $i => $tipo) {
        if ($tipo==='agregar_item' && !empty($items_ef[$i])) {
            $efectos[] = ['tipo'=>'agregar_item','item_id'=>(int)$items_ef[$i],'formula_cantidad'=>$fmls_ef[$i]??'1','posicion'=>null,'objeto_id'=>null];
        } elseif ($tipo==='cambiar_objeto' && !empty($poss_ef[$i]) && !empty($objs_ef[$i])) {
            $efectos[] = ['tipo'=>'cambiar_objeto','item_id'=>null,'formula_cantidad'=>null,'posicion'=>$poss_ef[$i],'objeto_id'=>(int)$objs_ef[$i]];
        }
    }
    $model->guardar_efectos($opcion_id, $efectos);
    flash_set('success','Opción guardada.'); redirect('/modelos.php?accion=opciones&id='.$id);
}

// ── ELIMINAR ──
if ($accion==='del_grupo' && $id) { $model->eliminar_grupo((int)$_GET['gid']); flash_set('success','Grupo eliminado.'); redirect('/modelos.php?accion=opciones&id='.$id); }
if ($accion==='del_opcion' && $id) { $model->eliminar_opcion((int)$_GET['oid']); flash_set('success','Opción eliminada.'); redirect('/modelos.php?accion=opciones&id='.$id); }
if ($accion==='eliminar' && $id) { $model->eliminar($id); flash_set('success','Modelo eliminado.'); redirect('/modelos.php'); }

$modelos = $model->listar();
$todos_objetos = $obj_model->listar();
$todos_items = $item_model->listar();
$modelo_edit = ($id&&in_array($accion,['editar','opciones'])) ? $model->buscar_por_id($id) : null;
$grupos = ($accion==='opciones'&&$id) ? $model->obtener_grupos($id) : [];

ob_start(); ?>
<?php if ($accion==='listar'): ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h6 class="mb-0 text-muted">Modelos de casa configurados</h6>
  <?php if(is_editor()):?><a href="/modelos.php?accion=editar" class="btn btn-sm btn-primary"><i class="bi bi-plus me-1"></i>Nuevo modelo</a><?php endif;?>
</div>
<div class="card">
  <table class="table table-hover mb-0">
    <thead><tr><th>Código</th><th>Nombre</th><th>Posiciones</th><th>Grupos de opciones</th><th></th></tr></thead>
    <tbody>
    <?php if(empty($modelos)):?>
      <tr><td colspan="5" class="text-center text-muted py-4">Sin modelos. Crea el primero.</td></tr>
    <?php else: foreach($modelos as $m):
      $pos = json_decode($m['posiciones_json'],true)??[];
      $db2 = Database::get();
      $ng = $db2->prepare('SELECT COUNT(*) FROM opcion_grupos WHERE modelo_id=? AND activo=1');
      $ng->execute([$m['id']]); $cnt_g=$ng->fetchColumn();
    ?>
    <tr>
      <td><code><?= e($m['codigo']) ?></code></td>
      <td class="fw-medium"><?= e($m['nombre']) ?></td>
      <td><span class="badge bg-light text-dark"><?= count($pos) ?> posiciones</span></td>
      <td><span class="badge bg-light text-dark"><?= $cnt_g ?> grupos</span></td>
      <td class="text-end">
        <a href="/modelos.php?accion=opciones&id=<?= $m['id'] ?>" class="btn btn-sm btn-primary">Configurar opciones</a>
        <a href="/modelos.php?accion=editar&id=<?= $m['id'] ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-pencil"></i></a>
        <a href="/modelos.php?accion=eliminar&id=<?= $m['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('¿Eliminar?')"><i class="bi bi-trash"></i></a>
      </td>
    </tr>
    <?php endforeach; endif;?>
    </tbody>
  </table>
</div>

<?php elseif(in_array($accion,['editar'])): ?>
<div class="card" style="max-width:600px">
  <div class="card-header"><?= $modelo_edit?'Editar modelo':'Nuevo modelo' ?></div>
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
      <input type="hidden" name="guardar_modelo" value="1">
      <div class="row g-2 mb-3">
        <div class="col-4"><label class="form-label fw-medium small">Código *</label>
          <input type="text" name="codigo" class="form-control form-control-sm text-uppercase" value="<?= e($modelo_edit['codigo']??'') ?>" required placeholder="STUDIO"></div>
        <div class="col-8"><label class="form-label fw-medium small">Nombre *</label>
          <input type="text" name="nombre" class="form-control form-control-sm" value="<?= e($modelo_edit['nombre']??'') ?>" required></div>
      </div>
      <div class="mb-3"><label class="form-label fw-medium small">Descripción</label>
        <textarea name="descripcion" class="form-control form-control-sm" rows="2"><?= e($modelo_edit['descripcion']??'') ?></textarea></div>

      <div class="fw-medium small mb-2">Posiciones del modelo</div>
      <div id="posiciones_lista">
      <?php
        $pos_act = json_decode($modelo_edit['posiciones_json']??'{}',true)??[];
        $def_act = json_decode($modelo_edit['objetos_default_json']??'{}',true)??[];
        if (empty($pos_act)) $pos_act = [1=>'Pared frontal',2=>'Pared trasera',3=>'Pared lateral izq.',4=>'Pared lateral der.'];
        if (empty($def_act)) $def_act = [1=>'A',2=>'A',3=>'A',4=>'A'];
        foreach ($pos_act as $i=>$nombre):
      ?>
      <div class="pos-row d-flex gap-2 mb-2 align-items-center">
        <span class="text-muted small" style="min-width:24px"><?= $i ?></span>
        <input type="text" name="pos_nombre[]" class="form-control form-control-sm" value="<?= e($nombre) ?>" placeholder="Nombre posición">
        <input type="text" name="pos_default[]" class="form-control form-control-sm text-uppercase" style="width:70px" value="<?= e($def_act[$i]??'A') ?>" placeholder="Obj.">
        <button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('.pos-row').remove()">×</button>
      </div>
      <?php endforeach; ?>
      </div>
      <button type="button" class="btn btn-sm btn-outline-secondary mb-3" onclick="agregarPos()">+ Posición</button>
      <div class="d-flex gap-2">
        <button type="submit" class="btn btn-sm btn-primary">Guardar y configurar opciones</button>
        <a href="/modelos.php" class="btn btn-sm btn-outline-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>
<script>
let posIdx = <?= max(array_keys($pos_act??[1=>0]))+1 ?>;
function agregarPos(){
  const lista=document.getElementById('posiciones_lista');
  const d=document.createElement('div'); d.className='pos-row d-flex gap-2 mb-2 align-items-center';
  d.innerHTML=`<span class="text-muted small" style="min-width:24px">${posIdx}</span><input type="text" name="pos_nombre[]" class="form-control form-control-sm" placeholder="Nombre posición"><input type="text" name="pos_default[]" class="form-control form-control-sm text-uppercase" style="width:70px" placeholder="Obj." value="A"><button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('.pos-row').remove()">×</button>`;
  lista.appendChild(d); posIdx++;
}
</script>

<?php elseif($accion==='opciones'&&$modelo_edit): ?>
<div class="d-flex align-items-center gap-3 mb-3">
  <a href="/modelos.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Modelos</a>
  <h6 class="mb-0"><?= e($modelo_edit['nombre']) ?> — Grupos de opciones</h6>
</div>

<?php foreach($grupos as $g): ?>
<div class="card mb-3">
  <div class="card-header">
    <div class="d-flex align-items-center gap-2">
      <span class="fw-medium"><?= e($g['nombre']) ?></span>
      <span class="badge bg-<?= $g['tipo']==='exclusivo'?'warning':'info' ?> text-dark"><?= $g['tipo'] ?></span>
      <?php if($g['requerido']):?><span class="badge bg-secondary">requerido</span><?php endif;?>
    </div>
    <a href="/modelos.php?accion=del_grupo&id=<?= $id ?>&gid=<?= $g['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('¿Eliminar grupo?')"><i class="bi bi-trash"></i></a>
  </div>
  <div class="card-body p-0">
    <table class="table table-sm mb-0">
      <thead><tr><th>Opción</th><th>Default</th><th>Efectos</th><th></th></tr></thead>
      <tbody>
      <?php foreach($g['opciones'] as $op): ?>
      <tr>
        <td class="fw-medium"><?= e($op['nombre']) ?></td>
        <td><?= $op['es_default']?'<span class="badge bg-success">sí</span>':'' ?></td>
        <td class="small text-muted">
          <?php foreach($op['efectos'] as $ef): ?>
            <?php if($ef['tipo']==='agregar_item'):?>
              <span class="badge bg-light text-dark me-1">+ <?= e($ef['item_nombre']??'') ?> ×<?= $ef['formula_cantidad'] ?></span>
            <?php else:?>
              <span class="badge bg-light text-dark me-1">pos.<?= $ef['posicion'] ?> → <?= e($ef['letra_config']??'') ?></span>
            <?php endif;?>
          <?php endforeach;?>
        </td>
        <td><a href="/modelos.php?accion=del_opcion&id=<?= $id ?>&oid=<?= $op['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('¿Eliminar?')">×</a></td>
      </tr>
      <?php endforeach;?>
      </tbody>
    </table>

    <!-- Agregar opción -->
    <div class="p-3 border-top">
      <div class="fw-medium small mb-2">+ Nueva opción</div>
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
        <input type="hidden" name="guardar_opcion" value="1">
        <input type="hidden" name="grupo_id" value="<?= $g['id'] ?>">
        <div class="row g-2 mb-2">
          <div class="col"><input type="text" name="opcion_nombre" class="form-control form-control-sm" placeholder="Nombre opción *" required></div>
          <div class="col-auto"><label class="form-check-label small me-1">Default</label>
            <input type="checkbox" name="es_default" value="1" class="form-check-input"></div>
        </div>
        <div id="efectos_<?= $g['id'] ?>"></div>
        <div class="d-flex gap-2 mb-2">
          <button type="button" class="btn btn-xs btn-outline-secondary btn-sm" onclick="addEfecto(<?= $g['id'] ?>,'agregar_item')">+ Agregar ítem</button>
          <button type="button" class="btn btn-xs btn-outline-secondary btn-sm" onclick="addEfecto(<?= $g['id'] ?>,'cambiar_objeto')">+ Cambiar objeto</button>
        </div>
        <button type="submit" class="btn btn-sm btn-primary">Guardar opción</button>
      </form>
    </div>
  </div>
</div>
<?php endforeach;?>

<!-- Nuevo grupo -->
<div class="card">
  <div class="card-header">+ Nuevo grupo de opciones</div>
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
      <input type="hidden" name="guardar_grupo" value="1">
      <div class="row g-2">
        <div class="col"><input type="text" name="nombre" class="form-control form-control-sm" placeholder="Nombre del grupo (ej: Color exterior)" required></div>
        <div class="col-auto">
          <select name="tipo" class="form-select form-select-sm">
            <option value="exclusivo">Exclusivo (elige uno)</option>
            <option value="toggle">Toggle (sí/no)</option>
          </select>
        </div>
        <div class="col-auto"><button type="submit" class="btn btn-sm btn-primary">Crear grupo</button></div>
      </div>
    </form>
  </div>
</div>

<script>
const todosItems = <?= json_encode(array_map(fn($i)=>['id'=>$i['id'],'nombre'=>$i['nombre'].' ('.$i['numero_parte'].')'], $todos_items)) ?>;
const todosObjetos = <?= json_encode(array_map(fn($o)=>['id'=>$o['id'],'nombre'=>$o['nombre'],'letra'=>$o['letra_config']], $todos_objetos)) ?>;
const posicionesModelo = <?= json_encode(array_keys(json_decode($modelo_edit['posiciones_json'],true)??[])) ?>;

function addEfecto(grupoId, tipo) {
  const div = document.getElementById('efectos_'+grupoId);
  const row = document.createElement('div');
  row.className = 'd-flex gap-2 mb-2 align-items-center';
  row.innerHTML = '<input type="hidden" name="efecto_tipo[]" value="'+tipo+'">';
  if (tipo==='agregar_item') {
    const sel = '<select name="efecto_item[]" class="form-select form-select-sm">'+todosItems.map(i=>'<option value="'+i.id+'">'+i.nombre+'</option>').join('')+'</select>';
    row.innerHTML += sel+'<input type="text" name="efecto_formula[]" class="form-control form-control-sm" style="width:80px" value="1" placeholder="cant."><input type="hidden" name="efecto_posicion[]" value=""><input type="hidden" name="efecto_objeto[]" value="">';
  } else {
    const selPos = '<select name="efecto_posicion[]" class="form-select form-select-sm">'+posicionesModelo.map(p=>'<option value="'+p+'">Pos. '+p+'</option>').join('')+'</select>';
    const selObj = '<select name="efecto_objeto[]" class="form-select form-select-sm">'+todosObjetos.map(o=>'<option value="'+o.id+'">'+o.letra+' — '+o.nombre+'</option>').join('')+'</select>';
    row.innerHTML += selPos+selObj+'<input type="hidden" name="efecto_item[]" value=""><input type="hidden" name="efecto_formula[]" value="">';
  }
  row.innerHTML += '<button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest(\'div\').remove()">×</button>';
  div.appendChild(row);
}
</script>
<?php endif;?>
<?php
$contenido = ob_get_clean();
$titulo = 'Modelos';
require_once __DIR__ . '/views/layout.php';
