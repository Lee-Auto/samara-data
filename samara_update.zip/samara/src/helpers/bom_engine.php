<?php
class BomEngine {
    private PDO $db;
    private array $parametros;
    private array $lineas = [];
    private array $visitados = [];

    public function __construct(PDO $db, array $parametros = []) {
        $this->db = $db;
        $this->parametros = $parametros;
    }

    public function explotar(string $codigo_config): array {
        $this->lineas = []; $this->visitados = [];
        $posiciones = $this->parsear_codigo($codigo_config);
        $objMap = $this->cargar_objetos();
        foreach ($posiciones as $pos => $letra) {
            $obj = $objMap[strtoupper($letra)] ?? null;
            if (!$obj) continue;
            $this->explotar_objeto($obj, $pos);
        }
        return $this->agrupar_lineas();
    }

    public function explotar_desde_modelo(int $modelo_id, array $opciones_ids): array {
        $this->lineas = []; $this->visitados = [];
        $stmt = $this->db->prepare('SELECT * FROM modelos WHERE id=? LIMIT 1');
        $stmt->execute([$modelo_id]);
        $modelo = $stmt->fetch();
        if (!$modelo) return ['agrupado'=>[],'detalle'=>[],'codigo'=>''];
        $posiciones = json_decode($modelo['posiciones_json'], true) ?: [];
        $objetos_pos = json_decode($modelo['objetos_default_json'], true) ?: [];
        $objMap = $this->cargar_objetos();
        $items_extra = [];
        foreach ($opciones_ids as $opcion_id) {
            $stmt2 = $this->db->prepare('SELECT * FROM opcion_efectos WHERE opcion_id=?');
            $stmt2->execute([$opcion_id]);
            foreach ($stmt2->fetchAll() as $e) {
                if ($e['tipo']==='cambiar_objeto' && $e['posicion'] && $e['objeto_id']) {
                    $stmt3 = $this->db->prepare('SELECT letra_config FROM objetos WHERE id=? LIMIT 1');
                    $stmt3->execute([$e['objeto_id']]);
                    $letra = $stmt3->fetchColumn();
                    if ($letra) $objetos_pos[$e['posicion']] = $letra;
                } elseif ($e['tipo']==='agregar_item' && $e['item_id']) {
                    $cant = $this->evaluar_formula($e['formula_cantidad']??'1');
                    $items_extra[$e['item_id']] = ($items_extra[$e['item_id']]??0) + $cant;
                }
            }
        }
        $codigo = implode('', array_values($objetos_pos));
        foreach ($objetos_pos as $pos => $letra) {
            $obj = $objMap[strtoupper($letra)] ?? null;
            if (!$obj) continue;
            $label = $posiciones[$pos] ?? "pos.$pos";
            $this->explotar_objeto($obj, $label);
        }
        foreach ($items_extra as $item_id => $cantidad) {
            $stmt4 = $this->db->prepare('SELECT * FROM items WHERE id=? LIMIT 1');
            $stmt4->execute([$item_id]);
            $item = $stmt4->fetch();
            if ($item) $this->lineas[] = ['item_id'=>$item_id,'numero_parte'=>$item['numero_parte'],'nombre'=>$item['nombre'],'unidad_medida'=>$item['unidad_medida'],'zona'=>$item['zona'],'cantidad'=>$cantidad,'origen_objeto'=>'Opción adicional','origen_articulo'=>''];
        }
        $resultado = $this->agrupar_lineas();
        $resultado['codigo'] = $codigo;
        return $resultado;
    }

    private function cargar_objetos(): array {
        $rows = $this->db->query('SELECT * FROM objetos WHERE activo=1')->fetchAll();
        $map = [];
        foreach ($rows as $o) $map[$o['letra_config']] = $o;
        return $map;
    }

    private function parsear_codigo(string $codigo): array {
        $codigo = strtoupper(trim($codigo));
        if (strpos($codigo,':')!==false) {
            $r=[];
            foreach (explode(',',$codigo) as $par) { [$k,$v]=array_map('trim',explode(':',$par,2)); $r[$k]=$v; }
            return $r;
        }
        $r=[];
        foreach (str_split($codigo) as $i=>$c) $r[$i+1]=$c;
        return $r;
    }

    private function explotar_objeto(array $objeto, mixed $posicion): void {
        $stmt=$this->db->prepare('SELECT oa.*,a.nombre as articulo_nombre FROM objeto_articulos oa JOIN articulos a ON a.id=oa.articulo_id WHERE oa.objeto_id=? ORDER BY oa.orden');
        $stmt->execute([$objeto['id']]);
        foreach ($stmt->fetchAll() as $oa) {
            $cant=$this->evaluar_formula($oa['formula_cantidad']);
            $this->explotar_articulo((int)$oa['articulo_id'],$cant,$objeto['nombre'].' ('.$posicion.')',$oa['articulo_nombre']);
        }
    }

    private function explotar_articulo(int $art_id, float $cant_padre, string $origen_obj, string $origen_art, int $depth=0): void {
        if ($depth>10||isset($this->visitados[$art_id.'_'.$depth])) return;
        $this->visitados[$art_id.'_'.$depth]=true;
        $stmt=$this->db->prepare('SELECT * FROM articulo_componentes WHERE articulo_id=?');
        $stmt->execute([$art_id]);
        foreach ($stmt->fetchAll() as $c) {
            $cant=$this->evaluar_formula($c['formula_cantidad'])*$cant_padre;
            if ($c['item_id']) {
                $stmt2=$this->db->prepare('SELECT * FROM items WHERE id=? LIMIT 1');
                $stmt2->execute([$c['item_id']]);
                $item=$stmt2->fetch();
                if ($item) $this->lineas[]=['item_id'=>(int)$c['item_id'],'numero_parte'=>$item['numero_parte'],'nombre'=>$item['nombre'],'unidad_medida'=>$item['unidad_medida'],'zona'=>$item['zona'],'cantidad'=>$cant,'origen_objeto'=>$origen_obj,'origen_articulo'=>$origen_art];
            } elseif ($c['sub_articulo_id']) {
                $stmt3=$this->db->prepare('SELECT nombre FROM articulos WHERE id=? LIMIT 1');
                $stmt3->execute([$c['sub_articulo_id']]);
                $sub=$stmt3->fetchColumn()?:'';
                $this->explotar_articulo((int)$c['sub_articulo_id'],$cant,$origen_obj,$origen_art.' > '.$sub,$depth+1);
            }
        }
    }

    private function evaluar_formula(string $formula): float {
        $formula=trim($formula);
        if (is_numeric($formula)) return (float)$formula;
        $expr=$formula;
        foreach ($this->parametros as $k=>$v) { if (is_numeric($v)) $expr=str_replace($k,(float)$v,$expr); }
        if (!preg_match('/^[\d\s\+\-\*\/\.\(\)]+$/',$expr)) return 1.0;
        try { $r=eval("return ($expr);"); return is_numeric($r)?(float)$r:1.0; } catch(Throwable){return 1.0;}
    }

    private function agrupar_lineas(): array {
        $agrupado=[];
        foreach ($this->lineas as $l) {
            $k=$l['item_id'];
            if (isset($agrupado[$k])) $agrupado[$k]['cantidad']+=$l['cantidad'];
            else $agrupado[$k]=$l;
        }
        usort($agrupado,fn($a,$b)=>strcmp($a['zona'],$b['zona'])?:strcmp($a['nombre'],$b['nombre']));
        return ['agrupado'=>array_values($agrupado),'detalle'=>$this->lineas];
    }
}
