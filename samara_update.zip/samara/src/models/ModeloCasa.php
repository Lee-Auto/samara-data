<?php
// src/models/ModeloCasa.php

class ModeloCasa {
    private PDO $db;
    public function __construct() { $this->db = Database::get(); }

    public function listar(): array {
        return $this->db->query('SELECT * FROM modelos WHERE activo=1 ORDER BY nombre')->fetchAll();
    }

    public function buscar_por_id(int $id): ?array {
        $stmt = $this->db->prepare('SELECT * FROM modelos WHERE id=? LIMIT 1');
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function crear(array $data, int $user_id): int {
        $stmt = $this->db->prepare(
            'INSERT INTO modelos (codigo, nombre, descripcion, posiciones_json, objetos_default_json)
             VALUES (?,?,?,?,?)'
        );
        $stmt->execute([
            strtoupper($data['codigo']),
            $data['nombre'],
            $data['descripcion'] ?? '',
            $data['posiciones_json'],
            $data['objetos_default_json'],
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function actualizar(int $id, array $data): bool {
        $stmt = $this->db->prepare(
            'UPDATE modelos SET codigo=?, nombre=?, descripcion=?, posiciones_json=?, objetos_default_json=?, updated_at=NOW() WHERE id=?'
        );
        return $stmt->execute([
            strtoupper($data['codigo']),
            $data['nombre'],
            $data['descripcion'] ?? '',
            $data['posiciones_json'],
            $data['objetos_default_json'],
            $id,
        ]);
    }

    public function eliminar(int $id): bool {
        $stmt = $this->db->prepare('UPDATE modelos SET activo=0 WHERE id=?');
        return $stmt->execute([$id]);
    }

    public function obtener_grupos(int $modelo_id): array {
        $stmt = $this->db->prepare(
            'SELECT * FROM opcion_grupos WHERE modelo_id=? AND activo=1 ORDER BY orden, nombre'
        );
        $stmt->execute([$modelo_id]);
        $grupos = $stmt->fetchAll();
        foreach ($grupos as &$g) {
            $g['opciones'] = $this->obtener_opciones($g['id']);
        }
        return $grupos;
    }

    public function obtener_opciones(int $grupo_id): array {
        $stmt = $this->db->prepare(
            'SELECT * FROM opciones WHERE grupo_id=? AND activo=1 ORDER BY orden, nombre'
        );
        $stmt->execute([$grupo_id]);
        $opciones = $stmt->fetchAll();
        foreach ($opciones as &$o) {
            $o['efectos'] = $this->obtener_efectos($o['id']);
        }
        return $opciones;
    }

    public function obtener_efectos(int $opcion_id): array {
        $stmt = $this->db->prepare(
            'SELECT oe.*, i.nombre as item_nombre, i.numero_parte, ob.nombre as objeto_nombre, ob.letra_config
             FROM opcion_efectos oe
             LEFT JOIN items i ON i.id = oe.item_id
             LEFT JOIN objetos ob ON ob.id = oe.objeto_id
             WHERE oe.opcion_id = ?'
        );
        $stmt->execute([$opcion_id]);
        return $stmt->fetchAll();
    }

    public function guardar_grupo(int $modelo_id, array $data): int {
        if (!empty($data['id'])) {
            $stmt = $this->db->prepare(
                'UPDATE opcion_grupos SET nombre=?, descripcion=?, tipo=?, requerido=?, orden=? WHERE id=?'
            );
            $stmt->execute([$data['nombre'], $data['descripcion']??'', $data['tipo'], $data['requerido']??1, $data['orden']??0, $data['id']]);
            return (int)$data['id'];
        }
        $stmt = $this->db->prepare(
            'INSERT INTO opcion_grupos (modelo_id, nombre, descripcion, tipo, requerido, orden) VALUES (?,?,?,?,?,?)'
        );
        $stmt->execute([$modelo_id, $data['nombre'], $data['descripcion']??'', $data['tipo']??'exclusivo', $data['requerido']??1, $data['orden']??0]);
        return (int)$this->db->lastInsertId();
    }

    public function guardar_opcion(int $grupo_id, array $data): int {
        if (!empty($data['id'])) {
            $stmt = $this->db->prepare('UPDATE opciones SET nombre=?, descripcion=?, es_default=?, orden=? WHERE id=?');
            $stmt->execute([$data['nombre'], $data['descripcion']??'', $data['es_default']??0, $data['orden']??0, $data['id']]);
            return (int)$data['id'];
        }
        $stmt = $this->db->prepare('INSERT INTO opciones (grupo_id, nombre, descripcion, es_default, orden) VALUES (?,?,?,?,?)');
        $stmt->execute([$grupo_id, $data['nombre'], $data['descripcion']??'', $data['es_default']??0, $data['orden']??0]);
        return (int)$this->db->lastInsertId();
    }

    public function guardar_efectos(int $opcion_id, array $efectos): void {
        $this->db->prepare('DELETE FROM opcion_efectos WHERE opcion_id=?')->execute([$opcion_id]);
        $stmt = $this->db->prepare(
            'INSERT INTO opcion_efectos (opcion_id, tipo, item_id, formula_cantidad, posicion, objeto_id)
             VALUES (?,?,?,?,?,?)'
        );
        foreach ($efectos as $e) {
            $stmt->execute([
                $opcion_id,
                $e['tipo'],
                !empty($e['item_id']) ? (int)$e['item_id'] : null,
                $e['formula_cantidad'] ?? null,
                $e['posicion'] ?? null,
                !empty($e['objeto_id']) ? (int)$e['objeto_id'] : null,
            ]);
        }
    }

    public function eliminar_grupo(int $id): bool {
        $stmt = $this->db->prepare('UPDATE opcion_grupos SET activo=0 WHERE id=?');
        return $stmt->execute([$id]);
    }

    public function eliminar_opcion(int $id): bool {
        $stmt = $this->db->prepare('UPDATE opciones SET activo=0 WHERE id=?');
        return $stmt->execute([$id]);
    }
}
